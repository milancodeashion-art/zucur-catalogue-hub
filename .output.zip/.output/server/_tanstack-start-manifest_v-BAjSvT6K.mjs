//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BAjSvT6K.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/auth",
			"/bulk-order-inquiry",
			"/contact",
			"/privacy-policy",
			"/terms",
			"/categories/$slug",
			"/products/$slug",
			"/categories/",
			"/products/",
			"/api/public/images/$"
		],
		preloads: [
			"/assets/index-4UYZG4Sd.js",
			"/assets/jsx-runtime-Dk72oS4N.js",
			"/assets/react-dom-CxAQt2Ay.js",
			"/assets/useStore-DG2WmC1C.js",
			"/assets/Match-BdtnWgoZ.js",
			"/assets/matchContext-Cp3bjMzx.js",
			"/assets/link-B1sIwsDb.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-4UYZG4Sd.js"
		} }]
	},
	"/": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bt21cwIa.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/createLucideIcon-C_LCJTxh.js",
			"/assets/arrow-right-CczGO6rn.js",
			"/assets/WhatsappEnquiryButton-D4kUqL_h.js",
			"/assets/clipboard-list-sVTcPZ0V.js",
			"/assets/message-circle-B6snYVnP.js",
			"/assets/truck-D05o4RBk.js",
			"/assets/dialog-DlkNff0R.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/ProductCard-D8zGFfj9.js"
		]
	},
	"/_authenticated": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin"],
		preloads: ["/assets/route-DcHSqdYJ.js"]
	},
	"/about": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about--VopnXni.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/createLucideIcon-C_LCJTxh.js",
			"/assets/WhatsappEnquiryButton-D4kUqL_h.js",
			"/assets/users-BwZkkB-R.js",
			"/assets/button-DbXrzmbF.js"
		]
	},
	"/auth": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-9Ki3-ktT.js",
			"/assets/createLucideIcon-C_LCJTxh.js",
			"/assets/loader-circle-CT4tTHMc.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/input-Y2S197YS.js",
			"/assets/zucur_logo-DdEwhPLs.js"
		]
	},
	"/bulk-order-inquiry": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/bulk-order-inquiry.tsx",
		children: void 0,
		preloads: [
			"/assets/bulk-order-inquiry-T9nlj-cc.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/WhatsappEnquiryButton-D4kUqL_h.js",
			"/assets/select-DvP8C0Mz.js",
			"/assets/badges-CgaXKITV.js",
			"/assets/loader-circle-CT4tTHMc.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/input-Y2S197YS.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/contact": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-Bk_cO7em.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/WhatsappEnquiryButton-D4kUqL_h.js",
			"/assets/button-DbXrzmbF.js"
		]
	},
	"/privacy-policy": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-DRYH70Au.js", "/assets/SiteLayout-FLZgcMIU.js"]
	},
	"/terms": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-zH6e9LON.js", "/assets/SiteLayout-FLZgcMIU.js"]
	},
	"/_authenticated/admin": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.tsx",
		children: [
			"/_authenticated/admin/banners",
			"/_authenticated/admin/categories",
			"/_authenticated/admin/inquiries",
			"/_authenticated/admin/products",
			"/_authenticated/admin/settings",
			"/_authenticated/admin/visitors",
			"/_authenticated/admin/whatsapp",
			"/_authenticated/admin/"
		],
		preloads: [
			"/assets/admin-D3WJpKN2.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/createLucideIcon-C_LCJTxh.js",
			"/assets/clipboard-list-sVTcPZ0V.js",
			"/assets/message-circle-B6snYVnP.js",
			"/assets/package-2PXSjMVl.js",
			"/assets/users-BwZkkB-R.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/zucur_logo-DdEwhPLs.js"
		]
	},
	"/categories/$slug": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/categories.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/categories._slug-ztXlM79L.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/ProductCard-D8zGFfj9.js"
		]
	},
	"/products/$slug": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/products.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/products._slug-C0iN5J2o.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/createLucideIcon-C_LCJTxh.js",
			"/assets/WhatsappEnquiryButton-D4kUqL_h.js",
			"/assets/badges-CgaXKITV.js",
			"/assets/image-off-BRfpPIGJ.js",
			"/assets/truck-D05o4RBk.js",
			"/assets/dialog-DlkNff0R.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/ProductCard-D8zGFfj9.js"
		]
	},
	"/categories/": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/categories.index.tsx",
		children: void 0,
		preloads: [
			"/assets/categories.index-B4jFoW1y.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/arrow-right-CczGO6rn.js",
			"/assets/dialog-DlkNff0R.js"
		]
	},
	"/products/": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/products.index.tsx",
		children: void 0,
		preloads: [
			"/assets/products.index-wVEQZLHX.js",
			"/assets/useQuery-Cy8wIJcD.js",
			"/assets/SiteLayout-FLZgcMIU.js",
			"/assets/select-DvP8C0Mz.js",
			"/assets/search-BfnvExII.js",
			"/assets/button-DbXrzmbF.js",
			"/assets/input-Y2S197YS.js",
			"/assets/ProductCard-D8zGFfj9.js"
		]
	},
	"/_authenticated/admin/banners": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.banners.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.banners-DtBsjRDX.js",
			"/assets/useMutation-dP6s1jTo.js",
			"/assets/image-off-BRfpPIGJ.js",
			"/assets/switch-DHu0V6MP.js",
			"/assets/dialog-DlkNff0R.js",
			"/assets/input-Y2S197YS.js",
			"/assets/Pagination-DWsVCHTt.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/_authenticated/admin/categories": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.categories.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.categories-D6CTDAyw.js",
			"/assets/useMutation-dP6s1jTo.js",
			"/assets/image-off-BRfpPIGJ.js",
			"/assets/switch-DHu0V6MP.js",
			"/assets/dialog-DlkNff0R.js",
			"/assets/input-Y2S197YS.js",
			"/assets/Pagination-DWsVCHTt.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/_authenticated/admin/inquiries": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.inquiries.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.inquiries-Dz6_OlNY.js",
			"/assets/useMutation-dP6s1jTo.js",
			"/assets/Pagination-DWsVCHTt.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/_authenticated/admin/products": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.products.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.products-BzV_EgOm.js",
			"/assets/useMutation-dP6s1jTo.js",
			"/assets/switch-DHu0V6MP.js",
			"/assets/search-BfnvExII.js",
			"/assets/dialog-DlkNff0R.js",
			"/assets/input-Y2S197YS.js",
			"/assets/Pagination-DWsVCHTt.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/_authenticated/admin/settings": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.settings-BgT4fofH.js",
			"/assets/useMutation-dP6s1jTo.js",
			"/assets/input-Y2S197YS.js",
			"/assets/textarea-DFm_dXg-.js"
		]
	},
	"/_authenticated/admin/visitors": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.visitors.tsx",
		children: void 0,
		preloads: ["/assets/admin.visitors-7WajisCl.js", "/assets/Pagination-DWsVCHTt.js"]
	},
	"/_authenticated/admin/whatsapp": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.whatsapp.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.whatsapp-D07weqit.js",
			"/assets/input-Y2S197YS.js",
			"/assets/Pagination-DWsVCHTt.js"
		]
	},
	"/_authenticated/admin/": {
		filePath: "D:/Flutter/flutter_projects/zucur-catalogue-hub/src/routes/_authenticated/admin.index.tsx",
		children: void 0,
		preloads: ["/assets/admin.index-II0um38v.js"]
	}
} });
//#endregion
export { tsrStartManifest };
