import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as Input } from "./input-CoDpKGui.mjs";
import { u as Search } from "../_libs/lucide-react.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as categoriesQuery, l as productsQuery, n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DUy71i1r.mjs";
import { n as ProductCard } from "./ProductCard-VzGlFIrQ.mjs";
import { t as Route } from "./products.index-iP6rjO7Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.index-bxZ-LHVa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductsPage() {
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	const { data: products = [], isLoading } = useQuery(productsQuery);
	const { data: categories = [] } = useQuery(categoriesQuery);
	const [term, setTerm] = (0, import_react.useState)(search["q"] ?? "");
	const [availability, setAvailability] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("newest");
	const activeQuery = (search["q"] ?? "").toLowerCase();
	const activeCategory = search["category"] ?? "all";
	const results = (0, import_react.useMemo)(() => {
		let list = products.filter((product) => {
			if (activeCategory !== "all") {
				const category = categories.find((c) => c.slug === activeCategory);
				if (!category || product.category_id !== category.id) return false;
			}
			if (availability !== "all" && product.stock_status !== availability) return false;
			if (!activeQuery) return true;
			return product.name.toLowerCase().includes(activeQuery) || product.sku.toLowerCase().includes(activeQuery) || (product.description ?? "").toLowerCase().includes(activeQuery) || String(product.price ?? "").includes(activeQuery) || String(product.discounted_price ?? "").includes(activeQuery);
		});
		list = [...list].sort((a, b) => {
			if (sort === "price-asc") return (a.price ?? Infinity) - (b.price ?? Infinity);
			if (sort === "price-desc") return (b.price ?? -Infinity) - (a.price ?? -Infinity);
			if (sort === "name") return a.name.localeCompare(b.name);
			return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
		});
		return list;
	}, [
		products,
		categories,
		activeCategory,
		activeQuery,
		availability,
		sort
	]);
	function applySearch(event) {
		event.preventDefault();
		navigate({ search: {
			...term.trim() ? { q: term.trim() } : {},
			...activeCategory !== "all" ? { category: activeCategory } : {}
		} });
	}
	function setCategory(value) {
		navigate({ search: {
			...search["q"] ? { q: search["q"] } : {},
			...value !== "all" ? { category: value } : {}
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Wholesale catalogue",
		title: "All products",
		subtitle: "Wholesale rates with minimum order quantity and live availability on every listing."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-card p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 lg:grid-cols-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
							onSubmit: applySearch,
							className: "lg:col-span-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: term,
									onChange: (e) => setTerm(e.target.value),
									placeholder: "Search by product name or SKU",
									className: "pl-8",
									"aria-label": "Search products"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: activeCategory,
								onValueChange: setCategory,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									"aria-label": "Filter by category",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "All categories" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									children: "All categories"
								}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: category.slug,
									children: category.name
								}, category.id))] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: availability,
								onValueChange: (value) => setAvailability(value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									"aria-label": "Filter by availability",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "all",
										children: "Any availability"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "available",
										children: "Available"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "stock_out",
										children: "Stock out"
									})
								] })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:col-span-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sort,
								onValueChange: (value) => setSort(value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									"aria-label": "Sort products",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "newest",
										children: "Newest first"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "price-asc",
										children: "Price: low to high"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "price-desc",
										children: "Price: high to low"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "name",
										children: "Name A–Z"
									})
								] })]
							})
						})
					]
				}), search["q"] ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted-foreground",
					children: [
						"Showing results for “",
						search["q"],
						"” ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "link",
							className: "h-auto p-0 text-xs",
							onClick: () => {
								setTerm("");
								navigate({ search: activeCategory !== "all" ? { category: activeCategory } : {} });
							},
							children: "clear search"
						})
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted-foreground",
				children: isLoading ? "Loading products…" : `${results.length} products`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: results.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
			}),
			!isLoading && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 rounded-lg border border-border bg-card p-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-bold text-navy",
					children: "No matching products"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Try a different search term, or send us your requirement directly."
				})]
			}) : null
		]
	})] });
}
//#endregion
export { ProductsPage as component };
