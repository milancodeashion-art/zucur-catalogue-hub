import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as useVisitor } from "./visitor-CyHULbu_.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { F as CircleCheck, w as LoaderCircle } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as categoriesQuery, l as productsQuery, n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
import { t as Route } from "./bulk-order-inquiry-BJFbEhWy.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DUy71i1r.mjs";
import { t as MoqBadge } from "./badges-B8CbVee5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bulk-order-inquiry-CN1NpKB5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BulkOrderInquiryPage() {
	const search = Route.useSearch();
	const { visitor } = useVisitor();
	const { data: products = [] } = useQuery(productsQuery);
	const { data: categories = [] } = useQuery(categoriesQuery);
	const [form, setForm] = (0, import_react.useState)({
		categorySlug: "",
		productSlug: search.product ?? "",
		companyName: "",
		quantity: "",
		name: "",
		phone: "",
		email: "",
		location: "",
		message: ""
	});
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (visitor) setForm((prev) => ({
			...prev,
			name: prev.name || visitor.name,
			phone: prev.phone || visitor.phone,
			email: prev.email || (visitor.email ?? "")
		}));
	}, [visitor]);
	const selected = products.find((p) => p.slug === form.productSlug) ?? null;
	const moq = selected?.moq ?? 1;
	(0, import_react.useEffect)(() => {
		if (!form.categorySlug && selected?.category?.slug) setForm((prev) => ({
			...prev,
			categorySlug: selected.category.slug
		}));
	}, [form.categorySlug, selected]);
	const activeCategory = categories.find((c) => c.slug === form.categorySlug) ?? null;
	const categoryProducts = activeCategory ? products.filter((p) => p.category_id === activeCategory.id) : [];
	(0, import_react.useEffect)(() => {
		if (selected && !form.quantity) setForm((prev) => ({
			...prev,
			quantity: String(selected.moq)
		}));
	}, [selected, form.quantity]);
	function update(key, value) {
		setForm((prev) => ({
			...prev,
			[key]: value
		}));
	}
	async function handleSubmit(event) {
		event.preventDefault();
		const next = {};
		const quantity = Number(form.quantity);
		if (form.name.trim().length < 2) next.name = "Enter your name";
		if (form.phone.trim().replace(/\D/g, "").length < 8) next.phone = "Enter a valid phone number";
		if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) next.email = "Enter a valid email address";
		if (!Number.isFinite(quantity) || quantity < 1) next.quantity = "Enter the quantity you need";
		else if (selected && quantity < moq) next.quantity = `Minimum order quantity is ${moq} units`;
		if (!form.productSlug && form.message.trim().length < 5) next.message = "Describe the products and quantities you need";
		setErrors(next);
		if (Object.keys(next).length > 0) return;
		setSaving(true);
		const { error } = await supabase.from("bulk_order_inquiries").insert({
			visitor_id: visitor?.id ?? null,
			product_id: selected?.id ?? null,
			product_name: selected?.name ?? "Multiple / custom requirement",
			product_sku: selected?.sku ?? null,
			company_name: form.companyName.trim() || null,
			required_quantity: Math.round(quantity),
			customer_name: form.name.trim(),
			customer_phone: form.phone.trim(),
			customer_email: form.email.trim() || null,
			delivery_location: form.location.trim() || null,
			message: form.message.trim() || null
		});
		setSaving(false);
		if (error) {
			toast.error("Could not send your inquiry. Please try again.");
			return;
		}
		setDone(true);
		toast.success("Inquiry received — our wholesale desk will contact you shortly.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Wholesale enquiry",
		title: "Bulk order inquiry",
		subtitle: "Tell us the product, quantity and delivery city. We reply with slab pricing, packing details and dispatch timelines."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-8 px-4 py-12 lg:grid-cols-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "lg:col-span-2",
			children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-success/30 bg-success/5 p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto size-10 text-success" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 font-display text-2xl font-extrabold text-navy",
						children: "Inquiry submitted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: [
							"Reference saved against ",
							form.name.trim(),
							" · ",
							form.phone.trim(),
							". Our team will share a wholesale quotation within one working day."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {
							product: selected,
							label: "Follow up on WhatsApp"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								setDone(false);
								setForm((prev) => ({
									...prev,
									categorySlug: "",
									productSlug: "",
									quantity: "",
									message: ""
								}));
							},
							children: "Submit another inquiry"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "grid gap-5 rounded-lg border border-border bg-card p-6 shadow-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "category",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: form.categorySlug || "none",
							onValueChange: (value) => {
								const slug = value === "none" ? "" : value;
								setForm((prev) => ({
									...prev,
									categorySlug: slug,
									productSlug: "",
									quantity: ""
								}));
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "category",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a category" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "none",
								children: "Multiple / custom requirement"
							}), categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: category.slug,
								children: category.name
							}, category.id))] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "product",
								children: "Product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: form.productSlug || "none",
								disabled: !form.categorySlug,
								onValueChange: (value) => {
									const slug = value === "none" ? "" : value;
									const next = products.find((p) => p.slug === slug);
									setForm((prev) => ({
										...prev,
										productSlug: slug,
										quantity: next ? String(next.moq) : ""
									}));
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									id: "product",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: form.categorySlug ? "Select a product" : "Please select a category first" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "none",
									children: "Not product specific"
								}), categoryProducts.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: product.slug,
									children: [
										product.name,
										" · ",
										product.sku
									]
								}, product.id))] })]
							}),
							!form.categorySlug ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Please select a category first."
							}) : categoryProducts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "No products available in this category."
							}) : null
						]
					}),
					selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 text-xs text-muted-foreground sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["SKU: ", selected.sku] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoqBadge, { moq: selected.moq })]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "quantity",
								children: "Required quantity *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "quantity",
								type: "number",
								min: selected ? selected.moq : 1,
								value: form.quantity,
								onChange: (e) => update("quantity", e.target.value),
								placeholder: selected ? `Minimum ${moq}` : "e.g. 500"
							}),
							errors.quantity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.quantity
							}) : selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									"Minimum order quantity for this item is ",
									moq,
									" units."
								]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "company",
							children: "Company name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "company",
							value: form.companyName,
							maxLength: 120,
							onChange: (e) => update("companyName", e.target.value),
							placeholder: "Business / firm name"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "name",
								children: "Contact person *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "name",
								value: form.name,
								maxLength: 100,
								onChange: (e) => update("name", e.target.value)
							}),
							errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.name
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "phone",
								children: "Phone *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "phone",
								value: form.phone,
								maxLength: 20,
								inputMode: "tel",
								onChange: (e) => update("phone", e.target.value)
							}),
							errors.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.phone
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "email",
								children: "Email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "email",
								value: form.email,
								maxLength: 150,
								onChange: (e) => update("email", e.target.value)
							}),
							errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.email
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "location",
							children: "Delivery location"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "location",
							value: form.location,
							maxLength: 150,
							onChange: (e) => update("location", e.target.value),
							placeholder: "City, state"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "message",
								children: "Requirement details"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "message",
								value: form.message,
								maxLength: 1e3,
								rows: 4,
								onChange: (e) => update("message", e.target.value),
								placeholder: "Packing preference, delivery timeline, other SKUs required…"
							}),
							errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.message
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							size: "lg",
							disabled: saving,
							className: "w-full sm:w-auto",
							children: [saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : null, "Submit bulk inquiry"]
						})
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-5 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base font-bold text-navy",
						children: "How it works"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 space-y-3 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. Share the product and quantity you need." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. We check stock and confirm slab pricing." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. You receive a written quotation with dispatch timeline." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4. Order is confirmed offline against a GST invoice." })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-5 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-base font-bold text-navy",
							children: "Prefer chatting?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Send your requirement on WhatsApp and get a quicker first response."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {
							className: "mt-4 w-full",
							product: selected
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-5 text-sm text-muted-foreground shadow-sm",
					children: [
						"Looking for something not listed?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "font-semibold text-primary hover:underline",
							children: "Contact our sourcing team"
						}),
						"."
					]
				})
			]
		})]
	})] });
}
//#endregion
export { BulkOrderInquiryPage as component };
