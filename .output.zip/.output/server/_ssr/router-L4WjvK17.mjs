import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { t as VisitorProvider } from "./visitor-CyHULbu_.mjs";
import { _ as useRouter, c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, k as redirect, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$19 } from "./bulk-order-inquiry-BJFbEhWy.mjs";
import { t as Route$20 } from "./categories._slug-DqAM6qav.mjs";
import { t as Route$21 } from "./products._slug-C4jFHeBm.mjs";
import { t as Route$22 } from "./products.index-iP6rjO7Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-L4WjvK17.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DKcUZ5Cw.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var BUSINESS_SCHEMA = {
	"@context": "https://schema.org",
	"@type": "WholesaleStore",
	name: "ZUCUR MART",
	url: "/",
	email: "info@zucur.com",
	telephone: "+91 6359061362",
	description: "ZUCUR MART is a wholesale supplier in Surat, Gujarat offering packaging, hygiene, disposables, stationery and kitchenware for business buyers.",
	address: {
		"@type": "PostalAddress",
		streetAddress: "38 The Galleria, Near Anupam Business Hub, Yogi Chowk Ground, Chikuwadi, Varachha",
		addressLocality: "Surat",
		addressRegion: "Gujarat",
		postalCode: "395011",
		addressCountry: "IN"
	},
	openingHours: "Mo-Sa 09:00-18:00",
	areaServed: "India"
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$18 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ZUCUR MART Surat — B2B Wholesale Supplier & Bulk Catalogue" },
			{
				name: "description",
				content: "ZUCUR MART is a Surat, Gujarat B2B wholesale supplier for packaging, hygiene, disposables, stationery and kitchenware with MOQ-based bulk pricing."
			},
			{
				name: "author",
				content: "ZUCUR MART"
			},
			{
				name: "keywords",
				content: "wholesale supplier Surat, bulk products Surat, packaging supplier Gujarat, ZUCUR MART"
			},
			{
				name: "telephone",
				content: "+91 6359061362"
			},
			{
				name: "email",
				content: "info@zucur.com"
			},
			{
				name: "geo.region",
				content: "IN-GJ"
			},
			{
				name: "geo.placename",
				content: "Surat"
			},
			{
				property: "og:title",
				content: "ZUCUR MART Surat — B2B Wholesale Supplier"
			},
			{
				property: "og:description",
				content: "Wholesale rates, MOQ and bulk order inquiries for business buyers in Surat and across India."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				property: "og:locale",
				content: "en_IN"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Manrope:wght@600;700;800&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			children: JSON.stringify(BUSINESS_SCHEMA)
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$18.useRouteContext();
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		const { data } = supabase.auth.onAuthStateChange((event) => {
			if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
			router.invalidate();
			if (event !== "SIGNED_OUT") queryClient.invalidateQueries();
		});
		return () => data.subscription.unsubscribe();
	}, [router, queryClient]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(VisitorProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			position: "top-right",
			richColors: true
		})] })
	});
}
var $$splitComponentImporter$16 = () => import("./routes-D3qAmjbp.mjs");
var Route$17 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "ZUCUR MART Surat — Wholesale Supplier & Bulk Orders" },
		{
			name: "description",
			content: "Wholesale supplier in Surat, Gujarat for packaging, hygiene, disposables, stationery and kitchenware. Compare MOQ, wholesale rates and send bulk orders on WhatsApp."
		},
		{
			property: "og:title",
			content: "ZUCUR MART Surat — B2B Wholesale Supplier"
		},
		{
			property: "og:description",
			content: "Browse wholesale rates, MOQ and stock availability from ZUCUR MART in Surat. Enquire on WhatsApp or submit a bulk order inquiry."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./route-Di7iQBCH.mjs");
var Route$16 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/auth" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./about-Lp3gC7mk.mjs");
var Route$15 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About ZUCUR MART — Wholesale Supply House" },
		{
			name: "description",
			content: "ZUCUR MART is a B2B wholesale supplier of packaging, hygiene, disposables, stationery and kitchenware for retailers, distributors, hotels and institutions."
		},
		{
			property: "og:title",
			content: "About ZUCUR MART"
		},
		{
			property: "og:description",
			content: "A wholesale-only supply house serving businesses across India."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./auth-CVKKWrFm.mjs");
var Route$14 = createFileRoute("/auth")({
	head: () => ({ meta: [
		{ title: "Admin Sign In — ZUCUR MART" },
		{
			name: "description",
			content: "Secure sign-in for the ZUCUR MART wholesale administration portal."
		},
		{
			property: "og:title",
			content: "Admin Sign In — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Staff access to the ZUCUR MART admin portal."
		},
		{
			name: "robots",
			content: "noindex"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./contact-Bv7BpQxw.mjs");
var Route$13 = createFileRoute("/contact")({
	head: () => ({ meta: [
		{ title: "Contact ZUCUR MART — Wholesale Desk" },
		{
			name: "description",
			content: "Contact the ZUCUR MART wholesale desk by phone, email or WhatsApp for bulk pricing, stock availability and dispatch queries."
		},
		{
			property: "og:title",
			content: "Contact ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Reach our wholesale desk for bulk pricing and stock availability."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./privacy-policy-O1TUdqkZ.mjs");
var Route$12 = createFileRoute("/privacy-policy")({
	head: () => ({ meta: [
		{ title: "Privacy Policy — ZUCUR MART" },
		{
			name: "description",
			content: "How ZUCUR MART collects and uses the business contact details shared for wholesale enquiries and bulk order quotations."
		},
		{
			property: "og:title",
			content: "Privacy Policy — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Details on how wholesale enquiry information is handled."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./terms-DWxM2Yma.mjs");
var Route$11 = createFileRoute("/terms")({
	head: () => ({ meta: [
		{ title: "Terms & Conditions — ZUCUR MART Wholesale" },
		{
			name: "description",
			content: "Terms for using the ZUCUR MART wholesale catalogue: indicative pricing, minimum order quantities, quotations and order confirmation."
		},
		{
			property: "og:title",
			content: "Terms & Conditions — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Wholesale catalogue terms, MOQ rules and quotation process."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./admin-BL455JdY.mjs");
var Route$10 = createFileRoute("/_authenticated/admin")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./categories.index-CF-E1WKq.mjs");
var Route$9 = createFileRoute("/categories/")({
	head: () => ({ meta: [
		{ title: "Wholesale Categories — ZUCUR MART" },
		{
			name: "description",
			content: "Explore ZUCUR MART wholesale categories: packaging, cleaning and hygiene, disposables, office stationery, kitchenware and personal care."
		},
		{
			property: "og:title",
			content: "Wholesale Categories — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Browse bulk supply categories with MOQ and wholesale rates."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./admin.index-DmFbxeOW.mjs");
var Route$8 = createFileRoute("/_authenticated/admin/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./admin.banners-CX0pHvWF.mjs");
var Route$7 = createFileRoute("/_authenticated/admin/banners")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./admin.categories-DDBynbPF.mjs");
var Route$6 = createFileRoute("/_authenticated/admin/categories")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./admin.inquiries-Ckovy37k.mjs");
var Route$5 = createFileRoute("/_authenticated/admin/inquiries")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.products-yCCZ0D1j.mjs");
var Route$4 = createFileRoute("/_authenticated/admin/products")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./admin.settings-BN2wwGUC.mjs");
var Route$3 = createFileRoute("/_authenticated/admin/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./admin.visitors-qhAaxuLY.mjs");
var Route$2 = createFileRoute("/_authenticated/admin/visitors")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./admin.whatsapp-MurA30U4.mjs");
var Route$1 = createFileRoute("/_authenticated/admin/whatsapp")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var BUCKET = "catalogue";
var Route = createFileRoute("/api/public/images/$")({ server: { handlers: { GET: async ({ params }) => {
	const path = (params["_splat"] ?? "").replace(/^\/+/, "");
	if (!path || path.includes("..")) return new Response("Not found", { status: 404 });
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.storage.from(BUCKET).download(path);
	if (error || !data) return new Response("Not found", { status: 404 });
	return new Response(await data.arrayBuffer(), { headers: {
		"content-type": data.type || "image/jpeg",
		"cache-control": "public, max-age=31536000, immutable"
	} });
} } } });
var IndexRoute = Route$17.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$18
});
var AuthenticatedRouteRoute = Route$16.update({
	id: "/_authenticated",
	getParentRoute: () => Route$18
});
var AboutRoute = Route$15.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$18
});
var AuthRoute = Route$14.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$18
});
var BulkOrderInquiryRoute = Route$19.update({
	id: "/bulk-order-inquiry",
	path: "/bulk-order-inquiry",
	getParentRoute: () => Route$18
});
var ContactRoute = Route$13.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$18
});
var PrivacyPolicyRoute = Route$12.update({
	id: "/privacy-policy",
	path: "/privacy-policy",
	getParentRoute: () => Route$18
});
var TermsRoute = Route$11.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$18
});
var AuthenticatedAdminRoute = Route$10.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => AuthenticatedRouteRoute
});
var CategoriesIndexRoute = Route$9.update({
	id: "/categories/",
	path: "/categories/",
	getParentRoute: () => Route$18
});
var CategoriesSlugRoute = Route$20.update({
	id: "/categories/$slug",
	path: "/categories/$slug",
	getParentRoute: () => Route$18
});
var ProductsIndexRoute = Route$22.update({
	id: "/products/",
	path: "/products/",
	getParentRoute: () => Route$18
});
var ProductsSlugRoute = Route$21.update({
	id: "/products/$slug",
	path: "/products/$slug",
	getParentRoute: () => Route$18
});
var AuthenticatedAdminIndexRoute = Route$8.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminBannersRoute = Route$7.update({
	id: "/banners",
	path: "/banners",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminCategoriesRoute = Route$6.update({
	id: "/categories",
	path: "/categories",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminInquiriesRoute = Route$5.update({
	id: "/inquiries",
	path: "/inquiries",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminProductsRoute = Route$4.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminSettingsRoute = Route$3.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminVisitorsRoute = Route$2.update({
	id: "/visitors",
	path: "/visitors",
	getParentRoute: () => AuthenticatedAdminRoute
});
var AuthenticatedAdminWhatsappRoute = Route$1.update({
	id: "/whatsapp",
	path: "/whatsapp",
	getParentRoute: () => AuthenticatedAdminRoute
});
var ApiPublicImagesSplatRoute = Route.update({
	id: "/api/public/images/$",
	path: "/api/public/images/$",
	getParentRoute: () => Route$18
});
var AuthenticatedAdminRouteChildren = {
	AuthenticatedAdminBannersRoute,
	AuthenticatedAdminCategoriesRoute,
	AuthenticatedAdminInquiriesRoute,
	AuthenticatedAdminProductsRoute,
	AuthenticatedAdminSettingsRoute,
	AuthenticatedAdminVisitorsRoute,
	AuthenticatedAdminWhatsappRoute,
	AuthenticatedAdminIndexRoute
};
var AuthenticatedRouteRouteChildren = { AuthenticatedAdminRoute: AuthenticatedAdminRoute._addFileChildren(AuthenticatedAdminRouteChildren) };
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	AuthRoute,
	BulkOrderInquiryRoute,
	ContactRoute,
	PrivacyPolicyRoute,
	TermsRoute,
	CategoriesSlugRoute,
	ProductsSlugRoute,
	CategoriesIndexRoute,
	ProductsIndexRoute,
	ApiPublicImagesSplatRoute
};
var routeTree = Route$18._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
