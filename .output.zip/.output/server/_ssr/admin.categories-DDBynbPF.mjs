import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { O as ImageOff, a as Trash2, d as Plus, m as Pencil } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, s as imageSrc, t as Dialog } from "./dialog-CGvJfmGP.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Switch, t as ImageUploader } from "./switch-f6_bOPf-.mjs";
import { t as Pagination } from "./Pagination-fwbkWNUq.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.categories-DDBynbPF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 10;
var EMPTY = {
	name: "",
	slug: "",
	description: "",
	image: "",
	display_order: "0",
	active: true
};
function slugify(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function AdminCategories() {
	const queryClient = useQueryClient();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(1);
	const categories = useQuery({
		queryKey: ["admin-categories", page],
		queryFn: async () => {
			const from = (page - 1) * PAGE_SIZE;
			const { data, error, count } = await supabase.from("categories").select("id, name, slug, description, image, display_order, active", { count: "exact" }).order("display_order").range(from, from + PAGE_SIZE - 1);
			if (error) throw error;
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	(0, import_react.useEffect)(() => {
		const total = categories.data?.count ?? 0;
		const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
		if (page > pageCount) setPage(pageCount);
	}, [categories.data?.count, page]);
	const save = useMutation({
		mutationFn: async (input) => {
			const payload = {
				name: input.name.trim(),
				slug: input.slug.trim() || slugify(input.name),
				description: input.description.trim() || null,
				image: input.image.trim() || null,
				display_order: Number(input.display_order) || 0,
				active: input.active
			};
			if (input.id) {
				const { error } = await supabase.from("categories").update(payload).eq("id", input.id);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("categories").insert(payload);
				if (error) throw error;
			}
		},
		onSuccess: () => {
			toast.success("Category saved");
			setDraft(null);
			queryClient.invalidateQueries({ queryKey: ["admin-categories"] });
			queryClient.invalidateQueries({ queryKey: ["admin-categories-list"] });
			queryClient.invalidateQueries({ queryKey: ["categories"] });
		},
		onError: () => toast.error("Could not save the category. Please try again.")
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("categories").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Category deleted");
			queryClient.invalidateQueries({ queryKey: ["admin-categories"] });
			queryClient.invalidateQueries({ queryKey: ["admin-categories-list"] });
			queryClient.invalidateQueries({ queryKey: ["categories"] });
		},
		onError: () => toast.error("Could not delete this category. Please try again.")
	});
	const rows = categories.data?.rows ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-extrabold text-navy",
					children: "Categories"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Organise the catalogue into wholesale categories."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New category"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Image"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Slug"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Actions"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: categories.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 6,
							className: "px-4 py-6 text-muted-foreground",
							children: "Loading…"
						}) }) : rows.length ? rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: c.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: imageSrc(c.image) ?? "",
									alt: c.name,
									className: "size-12 rounded-md border border-border object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-12 place-items-center rounded-md bg-secondary text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "size-4" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium text-navy",
								children: c.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: c.slug
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: c.display_order
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: c.active ? "Active" : "Hidden"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setDraft({
											id: c.id,
											name: c.name,
											slug: c.slug,
											description: c.description ?? "",
											image: c.image ?? "",
											display_order: String(c.display_order),
											active: c.active
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (confirm(`Delete ${c.name}?`)) remove.mutate(c.id);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
									})]
								})
							})
						] }, c.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 6,
							className: "px-4 py-6 text-muted-foreground",
							children: "No categories yet."
						}) })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				page,
				pageSize: PAGE_SIZE,
				total: categories.data?.count ?? 0,
				onPageChange: setPage,
				label: "categories"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: draft !== null,
				onOpenChange: (open) => !open && setDraft(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: draft?.id ? "Edit category" : "New category" }) }),
						draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "c-name",
									children: "Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "c-name",
									value: draft.name,
									onChange: (e) => setDraft({
										...draft,
										name: e.target.value,
										slug: draft.id ? draft.slug : slugify(e.target.value)
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "c-slug",
									children: "URL slug"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "c-slug",
									value: draft.slug,
									onChange: (e) => setDraft({
										...draft,
										slug: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "c-desc",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "c-desc",
									rows: 3,
									value: draft.description,
									onChange: (e) => setDraft({
										...draft,
										description: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
									label: draft.image ? "Category image" : "Upload category image",
									folder: "categories",
									value: draft.image ? [draft.image] : [],
									onChange: (urls) => setDraft({
										...draft,
										image: urls[0] ?? ""
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "c-order",
									children: "Display order"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "c-order",
									type: "number",
									value: draft.display_order,
									onChange: (e) => setDraft({
										...draft,
										display_order: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "c-active",
										checked: draft.active,
										onCheckedChange: (v) => setDraft({
											...draft,
											active: v
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "c-active",
										children: "Visible on site"
									})]
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDraft(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: save.isPending,
							onClick: () => {
								if (!draft) return;
								if (!draft.name.trim()) {
									toast.error("Name is required");
									return;
								}
								save.mutate(draft);
							},
							children: save.isPending ? "Saving…" : "Save category"
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { AdminCategories as component };
