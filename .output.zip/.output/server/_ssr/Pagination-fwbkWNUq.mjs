import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Pagination-fwbkWNUq.js
var import_jsx_runtime = require_jsx_runtime();
function pageNumbers(page, pageCount) {
	return [.../* @__PURE__ */ new Set([
		1,
		pageCount,
		page,
		page - 1,
		page + 1
	])].filter((p) => p >= 1 && p <= pageCount).sort((a, b) => a - b);
}
function Pagination({ page, pageSize, total, onPageChange, label = "records" }) {
	const pageCount = Math.max(1, Math.ceil(total / pageSize));
	if (total === 0) return null;
	const from = (page - 1) * pageSize + 1;
	const to = Math.min(total, page * pageSize);
	const pages = pageNumbers(page, pageCount);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-between gap-3 sm:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Showing ",
				from,
				"–",
				to,
				" of ",
				total,
				" ",
				label
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-center gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					disabled: page <= 1,
					onClick: () => onPageChange(page - 1),
					children: "Previous"
				}),
				pages.map((p, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5",
					children: [index > 0 && p - pages[index - 1] > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "px-1 text-xs text-muted-foreground",
						children: "…"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: p === page ? "default" : "outline",
						className: "min-w-9",
						onClick: () => onPageChange(p),
						children: p
					})]
				}, p)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					disabled: page >= pageCount,
					onClick: () => onPageChange(page + 1),
					children: "Next"
				})
			]
		})]
	});
}
//#endregion
export { Pagination as t };
