import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn } from "./button-DRsC1qZi.mjs";
import { E as Layers, F as CircleCheck, g as PackageX } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badges-B8CbVee5.js
var import_jsx_runtime = require_jsx_runtime();
function MoqBadge({ moq, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1 rounded-md bg-gold/15 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-gold-foreground", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3" }),
			"MOQ: ",
			moq,
			" ",
			moq === 1 ? "Unit" : "Units"
		]
	});
}
function StockBadge({ status, className }) {
	const available = status === "available";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-semibold uppercase tracking-wide", available ? "bg-success/12 text-success" : "bg-destructive/10 text-destructive", className),
		children: [available ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageX, { className: "size-3" }), available ? "Available" : "Stock Out"]
	});
}
//#endregion
export { StockBadge as n, MoqBadge as t };
