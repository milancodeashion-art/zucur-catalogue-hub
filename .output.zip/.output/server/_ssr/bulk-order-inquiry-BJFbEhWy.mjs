import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bulk-order-inquiry-BJFbEhWy.js
var $$splitComponentImporter = () => import("./bulk-order-inquiry-CN1NpKB5.mjs");
var Route = createFileRoute("/bulk-order-inquiry")({
	validateSearch: (search) => {
		const product = typeof search["product"] === "string" && search["product"].trim() ? search["product"].trim().slice(0, 120) : void 0;
		return product ? { product } : {};
	},
	head: () => ({ meta: [
		{ title: "Bulk Order Inquiry — ZUCUR MART Wholesale" },
		{
			name: "description",
			content: "Send your bulk requirement to ZUCUR MART: product, quantity, company and delivery city. Wholesale quotations within one working day."
		},
		{
			property: "og:title",
			content: "Bulk Order Inquiry — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Share quantity and delivery details to receive a wholesale quotation."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
