//#region node_modules/.nitro/vite/services/ssr/assets/zucur_logo-BL-P8Q7S.js
var zucur_logo_default = "/assets/zucur_logo-DO8iOKc8.png";
//#endregion
export { zucur_logo_default as t };
