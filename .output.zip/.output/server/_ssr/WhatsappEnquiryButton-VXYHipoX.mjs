import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as useVisitor } from "./visitor-CyHULbu_.mjs";
import { U as BellRing, v as MessageCircle } from "../_libs/lucide-react.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as formatPrice, u as settingsQuery } from "./SiteLayout-DQjmCaE1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/WhatsappEnquiryButton-VXYHipoX.js
var import_jsx_runtime = require_jsx_runtime();
function digitsOnly(value) {
	return value.replace(/\D/g, "");
}
function buildEnquiryMessage(settings, product, visitor) {
	const lines = [];
	const business = settings?.business_name ?? "ZUCUR MART";
	if (product) {
		const stockOut = product.stock_status === "stock_out";
		lines.push(stockOut ? `Hello ${business}, I would like to know when this product will be available again.` : `Hello ${business}, I would like a wholesale quotation for the product below.`);
		lines.push("");
		lines.push("*Product Details*");
		lines.push(`Name: ${product.name}`);
		lines.push(`SKU: ${product.sku}`);
		if (product.category?.name) lines.push(`Category: ${product.category.name}`);
		const currency = settings?.currency ?? "INR";
		if (product.discounted_price !== null && product.discounted_price !== void 0) {
			lines.push(`Price: ${formatPrice(product.discounted_price, currency)} (offer)`);
			if (product.price !== null && product.price !== void 0) lines.push(`Regular Price: ${formatPrice(product.price, currency)}`);
		} else lines.push(`Price: ${formatPrice(product.price, currency)}`);
		lines.push(`MOQ: ${product.moq} Units`);
		lines.push(`Availability: ${stockOut ? "Stock Out" : "Available"}`);
		if (stockOut) {
			lines.push("");
			lines.push("Please notify me as soon as fresh stock arrives.");
		}
	} else lines.push(settings?.default_whatsapp_message?.trim() || `Hello ${business}, I would like to enquire about wholesale pricing.`);
	if (visitor) {
		lines.push("");
		lines.push("*My Details*");
		lines.push(`Name: ${visitor.name}`);
		lines.push(`Phone: ${visitor.phone}`);
		if (visitor.email) lines.push(`Email: ${visitor.email}`);
	}
	return lines.join("\n").slice(0, 1500);
}
function whatsappUrl(settings, product, visitor) {
	return `https://wa.me/${digitsOnly(settings?.whatsapp_number ?? "919000000000")}?text=${encodeURIComponent(buildEnquiryMessage(settings, product, visitor))}`;
}
async function logWhatsappEnquiry(params) {
	const { error } = await supabase.from("whatsapp_enquiries").insert({
		visitor_id: params.visitorId,
		product_id: params.productId,
		enquiry_type: params.enquiryType
	});
	if (error) console.error("Failed to log WhatsApp enquiry", error.message);
}
function WhatsappEnquiryButton({ product = null, className, size = "default", variant = "default", label }) {
	const { data: settings } = useQuery(settingsQuery);
	const { visitor } = useVisitor();
	const stockOut = product?.stock_status === "stock_out";
	function handleClick() {
		logWhatsappEnquiry({
			visitorId: visitor?.id ?? null,
			productId: product?.id ?? null,
			enquiryType: product ? stockOut ? "stock_alert" : "product" : "general"
		});
		window.open(whatsappUrl(settings ?? null, product, visitor), "_blank", "noopener,noreferrer");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		size,
		variant,
		onClick: handleClick,
		className: cn(variant === "default" && "bg-success text-success-foreground hover:bg-success/90", className),
		children: [stockOut ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellRing, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-4" }), label ?? (stockOut ? "Ask When Available" : "Enquire on WhatsApp")]
	});
}
//#endregion
export { WhatsappEnquiryButton as t };
