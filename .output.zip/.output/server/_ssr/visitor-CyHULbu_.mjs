import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/visitor-CyHULbu_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STORAGE_KEY = "zucur-mart-visitor";
var VisitorContext = (0, import_react.createContext)(null);
function readStored() {
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		return parsed?.id && parsed?.name && parsed?.phone ? parsed : null;
	} catch {
		return null;
	}
}
function VisitorProvider({ children }) {
	const [visitor, setVisitor] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const stored = readStored();
		setVisitor(stored);
		setReady(true);
		if (stored) supabase.rpc("register_visitor", {
			_name: stored.name,
			_phone: stored.phone,
			_visitor_id: stored.id,
			...stored.email ? { _email: stored.email } : {}
		});
	}, []);
	const register = (0, import_react.useCallback)(async (input) => {
		const email = input.email?.trim() ? input.email.trim() : null;
		const { data, error } = await supabase.rpc("register_visitor", {
			_name: input.name.trim(),
			_phone: input.phone.trim(),
			...email ? { _email: email } : {}
		});
		if (error) throw error;
		const record = {
			id: data,
			name: input.name.trim(),
			phone: input.phone.trim(),
			email
		};
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(record));
		setVisitor(record);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisitorContext.Provider, {
		value: {
			visitor,
			ready,
			register
		},
		children
	});
}
function useVisitor() {
	const ctx = (0, import_react.useContext)(VisitorContext);
	if (!ctx) throw new Error("useVisitor must be used inside VisitorProvider");
	return ctx;
}
//#endregion
export { useVisitor as n, VisitorProvider as t };
