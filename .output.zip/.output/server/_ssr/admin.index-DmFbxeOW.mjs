import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { P as ClipboardList, h as Package, i as TriangleAlert, n as Users, v as MessageCircle } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-DmFbxeOW.js
var import_jsx_runtime = require_jsx_runtime();
async function countOf(table) {
	const { count, error } = await supabase.from(table).select("id", {
		count: "exact",
		head: true
	});
	if (error) throw error;
	return count ?? 0;
}
function AdminDashboard() {
	const stats = useQuery({
		queryKey: ["admin-stats"],
		queryFn: async () => {
			const [products, visitors, whatsapp, bulk] = await Promise.all([
				countOf("products"),
				countOf("visitors"),
				countOf("whatsapp_enquiries"),
				countOf("bulk_order_inquiries")
			]);
			const { count: stockOut, error } = await supabase.from("products").select("id", {
				count: "exact",
				head: true
			}).eq("stock_status", "stock_out");
			if (error) throw error;
			return {
				products,
				visitors,
				whatsapp,
				bulk,
				stockOut: stockOut ?? 0
			};
		}
	});
	const recent = useQuery({
		queryKey: ["admin-recent-inquiries"],
		queryFn: async () => {
			const { data, error } = await supabase.from("bulk_order_inquiries").select("id, product_name, customer_name, company_name, required_quantity, status, created_at").order("created_at", { ascending: false }).limit(6);
			if (error) throw error;
			return data;
		}
	});
	const cards = [
		{
			label: "Total Products",
			value: stats.data?.products,
			icon: Package
		},
		{
			label: "Stock Out",
			value: stats.data?.stockOut,
			icon: TriangleAlert
		},
		{
			label: "Visitors",
			value: stats.data?.visitors,
			icon: Users
		},
		{
			label: "WhatsApp Enquiries",
			value: stats.data?.whatsapp,
			icon: MessageCircle
		},
		{
			label: "Bulk Inquiries",
			value: stats.data?.bulk,
			icon: ClipboardList
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-extrabold text-navy",
				children: "Dashboard"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Catalogue and enquiry activity at a glance."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-5",
				children: cards.map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-4 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wide text-muted-foreground",
							children: card.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(card.icon, { className: "size-4 text-primary" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-2xl font-extrabold text-navy",
						children: card.value ?? "—"
					})]
				}, card.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-card shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-border px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base font-bold text-navy",
						children: "Latest bulk inquiries"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/inquiries",
						className: "text-sm font-medium text-primary hover:underline",
						children: "View all"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y divide-border",
					children: recent.data?.length ? recent.data.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 px-4 py-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-navy",
								children: row.product_name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									"· ",
									row.required_quantity,
									" units"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted-foreground",
								children: [
									"· ",
									row.customer_name,
									row.company_name ? ` (${row.company_name})` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto rounded-full bg-muted px-2.5 py-0.5 text-xs font-semibold text-navy",
								children: row.status
							})
						]
					}, row.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 py-6 text-sm text-muted-foreground",
						children: "No inquiries yet."
					})
				})]
			})
		]
	});
}
//#endregion
export { AdminDashboard as component };
