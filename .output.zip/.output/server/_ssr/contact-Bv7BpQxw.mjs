import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { N as Clock, b as MapPin, f as Phone, x as Mail } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as SiteLayout, t as PageHeader, u as settingsQuery } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-Bv7BpQxw.js
var import_jsx_runtime = require_jsx_runtime();
var SOCIALS = [
	{
		label: "Telegram",
		href: "https://t.me/Newindiacart",
		color: "#229ED9",
		path: "M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 15.3l-1.99 1.93c-.23.23-.42.42-.83.42z"
	},
	{
		label: "Instagram",
		href: "https://www.instagram.com/zucur.mart?stkn=NXRrbjR0dmxtNTdk",
		color: "#E4405F",
		path: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.43.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.43.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.43-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.43-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16zm0 1.62c-3.15 0-3.5.01-4.74.07-1.14.05-1.76.24-2.17.4-.55.21-.94.47-1.35.88-.41.41-.67.8-.88 1.35-.16.41-.35 1.03-.4 2.17-.06 1.24-.07 1.59-.07 4.74s.01 3.5.07 4.74c.05 1.14.24 1.76.4 2.17.21.55.47.94.88 1.35.41.41.8.67 1.35.88.41.16 1.03.35 2.17.4 1.24.06 1.59.07 4.74.07s3.5-.01 4.74-.07c1.14-.05 1.76-.24 2.17-.4.55-.21.94-.47 1.35-.88.41-.41.67-.8.88-1.35.16-.41.35-1.03.4-2.17.06-1.24.07-1.59.07-4.74s-.01-3.5-.07-4.74c-.05-1.14-.24-1.76-.4-2.17a3.6 3.6 0 0 0-.88-1.35 3.6 3.6 0 0 0-1.35-.88c-.41-.16-1.03-.35-2.17-.4-1.24-.06-1.59-.07-4.74-.07zm0 2.76a5.4 5.4 0 1 1 0 10.8 5.4 5.4 0 0 1 0-10.8zm0 1.62a3.78 3.78 0 1 0 0 7.56 3.78 3.78 0 0 0 0-7.56zm5.6-3.39a1.26 1.26 0 1 1 0 2.52 1.26 1.26 0 0 1 0-2.52z"
	},
	{
		label: "YouTube",
		href: "https://youtube.com/@zucurstore?si=CsGQLlbgf_ovwsiy",
		color: "#FF0000",
		path: "M23.5 6.2a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 0 0 .5 6.2C0 8.07 0 12 0 12s0 3.93.5 5.8a3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z"
	}
];
var WHATSAPP_PATH = "M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2zm5.8 14.13c-.24.68-1.4 1.31-1.95 1.38-.5.07-1.13.1-1.82-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3 0-1.43.75-2.13 1.02-2.42.27-.29.58-.36.78-.36.19 0 .39 0 .56.01.18.01.42-.07.66.5.24.68.82 2.35.89 2.52.07.17.12.37.02.57-.09.2-.14.32-.28.49-.14.17-.29.38-.42.51-.14.14-.28.29-.12.57.16.28.7 1.16 1.5 1.88 1.03.92 1.9 1.2 2.18 1.34.27.14.43.12.59-.07.16-.2.68-.79.86-1.06.18-.27.36-.23.61-.14.25.09 1.58.75 1.85.88.27.14.45.2.52.31.07.11.07.65-.17 1.33z";
function digitsOnly(value) {
	return value.replace(/\D/g, "");
}
function SocialIcon({ path, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		fill: "currentColor",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: path })
	});
}
function ContactPage() {
	const { data: settings } = useQuery(settingsQuery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Contact",
		title: "Talk to our wholesale desk",
		subtitle: "Share your requirement by phone, email or WhatsApp — or submit a bulk order inquiry for a written quotation."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-6 px-4 py-12 lg:grid-cols-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 lg:col-span-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						settings?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactCard, {
							icon: Phone,
							label: "Phone",
							value: settings.phone,
							href: `tel:${settings.phone}`
						}) : null,
						settings?.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactCard, {
							icon: Mail,
							label: "Email",
							value: settings.email,
							href: `mailto:${settings.email}`
						}) : null,
						settings?.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactCard, {
							icon: MapPin,
							label: "Warehouse & office",
							value: settings.address
						}) : null,
						settings?.business_hours ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactCard, {
							icon: Clock,
							label: "Business hours",
							value: settings.business_hours
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-6 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold text-navy",
							children: "Connect with us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Follow ZUCUR MART for stock updates, new arrivals and seasonal wholesale offers."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap items-center gap-3",
							children: [SOCIALS.map((social) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: social.href,
								target: "_blank",
								rel: "noopener noreferrer",
								"aria-label": social.label,
								style: { backgroundColor: social.color },
								className: "group/social grid size-11 place-items-center rounded-full shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
									path: social.path,
									className: "size-5 text-white transition-transform duration-200 group-hover/social:scale-110"
								})
							}, social.label)), settings?.whatsapp_number ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `https://wa.me/${digitsOnly(settings.whatsapp_number)}`,
								target: "_blank",
								rel: "noopener noreferrer",
								"aria-label": "WhatsApp",
								style: { backgroundColor: "#25D366" },
								className: "group/social grid size-11 place-items-center rounded-full shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
									path: WHATSAPP_PATH,
									className: "size-5 text-white transition-transform duration-200 group-hover/social:scale-110"
								})
							}) : null]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-6 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold text-navy",
							children: "Need pricing for a volume?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "The fastest route to a wholesale rate is a bulk order inquiry — it captures product, quantity and delivery city in one go."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/bulk-order-inquiry",
									children: "Bulk Order Inquiry"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, { variant: "outline" })]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-lg border border-border bg-card p-6 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-base font-bold text-navy",
				children: "Good to know"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-3 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "We supply to registered businesses only — no single-unit retail sales." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Every product page lists its minimum order quantity." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Quotations are typically shared within one working day." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Freight and packing are quoted separately based on delivery city." })
				]
			})]
		})]
	})] });
}
function ContactCard({ icon: Icon, label, value, href }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card p-5 shadow-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-10 place-items-center rounded-md bg-primary/10 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
				children: label
			}),
			href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				className: "mt-1 block break-words text-sm font-medium text-navy hover:text-primary",
				children: value
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm font-medium text-navy",
				children: value
			})
		]
	});
}
//#endregion
export { ContactPage as component };
