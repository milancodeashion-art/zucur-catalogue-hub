import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products.index-iP6rjO7Q.js
var $$splitComponentImporter = () => import("./products.index-bxZ-LHVa.mjs");
var Route = createFileRoute("/products/")({
	validateSearch: (search) => {
		const q = typeof search["q"] === "string" && search["q"].trim() ? search["q"].trim().slice(0, 80) : void 0;
		const category = typeof search["category"] === "string" && search["category"].trim() ? search["category"].trim().slice(0, 80) : void 0;
		return {
			...q ? { q } : {},
			...category ? { category } : {}
		};
	},
	head: () => ({ meta: [
		{ title: "All Wholesale Products — ZUCUR MART" },
		{
			name: "description",
			content: "Search the full ZUCUR MART wholesale catalogue. Filter by category and availability, sort by price or newest, and check MOQ on every product."
		},
		{
			property: "og:title",
			content: "All Wholesale Products — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Wholesale rates, minimum order quantities and live stock status."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
