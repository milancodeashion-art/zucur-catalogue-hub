import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { V as Building2, _ as PackageCheck, k as Handshake, n as Users } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-Lp3gC7mk.js
var import_jsx_runtime = require_jsx_runtime();
var PILLARS = [
	{
		icon: Building2,
		title: "Wholesale only",
		text: "We supply businesses, not individual consumers. Every price on the catalogue is a bulk rate."
	},
	{
		icon: PackageCheck,
		title: "Stocked depth",
		text: "Fast-moving SKUs are held in depth so repeat orders ship without waiting on production."
	},
	{
		icon: Handshake,
		title: "Quotation-led",
		text: "No cart, no checkout. Pricing is confirmed against your volume, packing and delivery city."
	},
	{
		icon: Users,
		title: "Account managed",
		text: "A named contact handles your enquiries, follow-ups and dispatch tracking."
	}
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "About us",
		title: "A wholesale partner built for procurement teams",
		subtitle: "ZUCUR MART consolidates everyday business consumables into one supply line with transparent MOQ and wholesale rates."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-10 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4 text-sm leading-relaxed text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "ZUCUR MART began as a packaging supplier to local retailers and grew into a multi-category wholesale house. Today we serve kirana chains, distributors, cloud kitchens, hotels, hospitals, facility management firms and corporate procurement teams." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We publish minimum order quantities on every product so buyers can plan volume before asking for a price. Once you send a bulk inquiry, our desk checks live stock, applies slab pricing and returns a written quotation with dispatch timelines." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Because wholesale terms differ from buyer to buyer, ZUCUR MART deliberately has no shopping cart or online payment. Every order is confirmed offline against a GST invoice, which keeps freight, packing and credit terms negotiable." })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: PILLARS.map((pillar) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-5 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-md bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(pillar.icon, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-base font-bold text-navy",
							children: pillar.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
							children: pillar.text
						})
					]
				}, pillar.title))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 flex flex-wrap gap-3 rounded-xl bg-navy px-6 py-8 text-navy-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-extrabold",
					children: "Ready to compare wholesale rates?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-navy-foreground/75",
					children: "Browse the catalogue or send your requirement and we will quote within a day."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/products",
						children: "Browse catalogue"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {})]
			})]
		})]
	})] });
}
//#endregion
export { AboutPage as component };
