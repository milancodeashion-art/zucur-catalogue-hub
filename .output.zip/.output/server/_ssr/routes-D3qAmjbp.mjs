import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { G as ArrowRight, H as Boxes, L as ChevronRight, P as ClipboardList, R as ChevronLeft, W as BadgeCheck, b as MapPin, f as Phone, j as Factory, p as Percent, r as Truck, v as MessageCircle, x as Mail } from "../_libs/lucide-react.mjs";
import { s as imageSrc } from "./dialog-CGvJfmGP.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as categoriesQuery, l as productsQuery, n as SiteLayout, r as bannersQuery, u as settingsQuery } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
import { n as ProductCard } from "./ProductCard-VzGlFIrQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D3qAmjbp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var INTERVAL = 4500;
function HeroBannerCarousel({ banners }) {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const count = banners.length;
	const go = (0, import_react.useCallback)((next) => setIndex((next % count + count) % count), [count]);
	(0, import_react.useEffect)(() => {
		if (paused || count < 2) return;
		const timer = setInterval(() => setIndex((i) => (i + 1) % count), INTERVAL);
		return () => clearInterval(timer);
	}, [paused, count]);
	(0, import_react.useEffect)(() => {
		if (index >= count) setIndex(0);
	}, [count, index]);
	if (count === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-64 w-full overflow-hidden rounded-xl border border-navy-foreground/10 bg-navy-foreground/5 shadow-lg sm:h-80 lg:h-[22rem]",
		onMouseEnter: () => setPaused(true),
		onMouseLeave: () => setPaused(false),
		onTouchStart: () => setPaused(true),
		onTouchEnd: () => setPaused(false),
		"aria-roledescription": "carousel",
		"aria-label": "Featured offers",
		children: [banners.map((banner, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("absolute inset-0 transition-opacity duration-700 ease-out", i === index ? "opacity-100" : "pointer-events-none opacity-0"),
			"aria-hidden": i !== index,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: imageSrc(banner.image) ?? "",
				alt: banner.title ?? "ZUCUR MART offer",
				loading: i === 0 ? "eager" : "lazy",
				className: "size-full object-cover"
			}), banner.title || banner.description || banner.button_text ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 flex flex-col justify-end gap-2 bg-gradient-to-t from-navy/85 via-navy/35 to-transparent p-5 sm:p-7",
				children: [
					banner.title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-extrabold leading-tight text-white sm:text-2xl",
						children: banner.title
					}) : null,
					banner.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-md text-xs leading-relaxed text-white/80 sm:text-sm",
						children: banner.description
					}) : null,
					banner.button_text && banner.button_link ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: banner.button_link,
						className: "mt-1 inline-flex w-fit items-center rounded-md bg-gold px-4 py-2 text-xs font-bold text-gold-foreground transition-colors hover:bg-gold/90 sm:text-sm",
						children: banner.button_text
					}) : null
				]
			}) : null]
		}, banner.id)), count > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go(index - 1),
				"aria-label": "Previous banner",
				className: "absolute left-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-navy/60 text-white backdrop-blur transition-colors hover:bg-navy/80",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go(index + 1),
				"aria-label": "Next banner",
				className: "absolute right-2 top-1/2 grid size-9 -translate-y-1/2 place-items-center rounded-full bg-navy/60 text-white backdrop-blur transition-colors hover:bg-navy/80",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-x-0 bottom-3 flex justify-center gap-1.5",
				children: banners.map((banner, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => go(i),
					"aria-label": `Go to banner ${i + 1}`,
					className: cn("h-1.5 rounded-full transition-all", i === index ? "w-6 bg-gold" : "w-1.5 bg-white/60 hover:bg-white")
				}, banner.id))
			})
		] }) : null]
	});
}
var BENEFITS = [
	{
		icon: Percent,
		title: "True wholesale pricing",
		text: "Slab-based bulk rates that get sharper as your order quantity grows."
	},
	{
		icon: Boxes,
		title: "Clear MOQ on every item",
		text: "Minimum order quantity is printed on each product so planning is simple."
	},
	{
		icon: Truck,
		title: "Pan-India dispatch",
		text: "Palletised, transport-ready packing with LR tracking on every consignment."
	},
	{
		icon: BadgeCheck,
		title: "Consistent quality",
		text: "Factory-checked batches with specification sheets on request."
	},
	{
		icon: Factory,
		title: "Direct from source",
		text: "Manufacturer tie-ups remove middle layers from your cost sheet."
	},
	{
		icon: ClipboardList,
		title: "GST invoicing",
		text: "Proper tax invoices and documentation for every wholesale purchase."
	}
];
function HomePage() {
	const { data: categories = [] } = useQuery(categoriesQuery);
	const { data: products = [] } = useQuery(productsQuery);
	const { data: settings } = useQuery(settingsQuery);
	const { data: banners = [] } = useQuery(bannersQuery);
	const featured = products.filter((p) => p.featured).slice(0, 8);
	const newest = products.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-navy text-navy-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 opacity-25 [background:radial-gradient(circle_at_20%_10%,var(--color-primary),transparent_55%),radial-gradient(circle_at_85%_80%,var(--color-gold),transparent_45%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid max-w-7xl gap-10 px-4 py-14 lg:grid-cols-2 lg:items-center lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-semibold uppercase tracking-[0.28em] text-gold",
						children: "B2B Wholesale · No retail sales"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-4xl font-extrabold leading-tight sm:text-5xl",
						children: "Bulk supply, sharper margins for your business"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-sm leading-relaxed text-navy-foreground/80 sm:text-base",
						children: "ZUCUR MART supplies retailers, distributors, hotels, offices and institutions with packaging, hygiene, disposables, stationery and kitchenware at wholesale rates. Browse the catalogue, check MOQ, and send your requirement in one tap."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/products",
								children: ["Browse Catalogue ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "outline",
							className: "border-gold/60 bg-transparent text-gold hover:bg-gold hover:text-gold-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bulk-order-inquiry",
								children: "Bulk Order Inquiry"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-navy-foreground/15 pt-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
								className: "font-display text-2xl font-extrabold text-gold",
								children: [products.length, "+"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-xs text-navy-foreground/70",
								children: "Wholesale SKUs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-2xl font-extrabold text-gold",
								children: categories.length
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-xs text-navy-foreground/70",
								children: "Supply categories"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-2xl font-extrabold text-gold",
								children: "24h"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "text-xs text-navy-foreground/70",
								children: "Quotation turnaround"
							})] })
						]
					})
				] }), banners.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroBannerCarousel, { banners }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: categories.slice(0, 4).map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/categories/$slug",
						params: { slug: category.slug },
						className: "group relative overflow-hidden rounded-lg border border-navy-foreground/10",
						children: [category.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: imageSrc(category.image) ?? "",
							alt: category.name,
							loading: "lazy",
							className: "h-32 w-full object-cover transition-transform duration-300 group-hover:scale-105 sm:h-44"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-32 w-full bg-navy-foreground/10 sm:h-44" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-x-0 bottom-0 bg-navy/80 px-3 py-2 text-xs font-semibold sm:text-sm",
							children: category.name
						})]
					}, category.id))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Shop by category",
				title: "Featured wholesale categories",
				action: {
					to: "/categories",
					label: "All categories"
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/categories/$slug",
					params: { slug: category.slug },
					className: "group flex gap-4 rounded-lg border border-border bg-card p-4 shadow-sm transition-shadow hover:shadow-md",
					children: [category.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: imageSrc(category.image) ?? "",
						alt: category.name,
						loading: "lazy",
						className: "size-20 shrink-0 rounded-md object-cover"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-base font-bold text-navy group-hover:text-primary",
							children: category.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 line-clamp-3 block text-xs leading-relaxed text-muted-foreground",
							children: category.description
						})]
					})]
				}, category.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-card py-14",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "Best sellers",
					title: "Featured products",
					action: {
						to: "/products",
						label: "View all products"
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: featured.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Why ZUCUR MART",
				title: "Built for wholesale buyers"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: BENEFITS.map((benefit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-5 shadow-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-10 place-items-center rounded-md bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(benefit.icon, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-4 font-display text-base font-bold text-navy",
							children: benefit.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-sm leading-relaxed text-muted-foreground",
							children: benefit.text
						})
					]
				}, benefit.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-xl bg-navy px-6 py-10 text-navy-foreground sm:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs font-semibold uppercase tracking-[0.25em] text-gold",
							children: "Bulk requirement?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-2xl font-extrabold sm:text-3xl",
							children: "Send your quantity, get a wholesale quotation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-2xl text-sm text-navy-foreground/75",
							children: "Share the products, quantities and delivery city. Our team responds with slab pricing and dispatch timelines within one working day."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bulk-order-inquiry",
								children: "Start Bulk Inquiry"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {
							size: "lg",
							label: "Enquire on WhatsApp"
						})]
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: "Latest additions",
				title: "New in the catalogue",
				action: {
					to: "/products",
					label: "See everything"
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: newest.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-success/10 py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col items-start gap-4 px-4 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 shrink-0 place-items-center rounded-full bg-success text-success-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-bold text-navy",
						children: "Faster answers on WhatsApp"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Product availability, slab rates and dispatch updates — chat with our wholesale desk."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, { size: "lg" })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-14 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: "About us",
					title: "A wholesale partner, not a marketplace"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm leading-relaxed text-muted-foreground",
					children: "ZUCUR MART operates strictly as a business-to-business supply house. We do not sell single units and there is no online checkout — every order is confirmed through a quotation so pricing reflects your actual volume, packing and delivery requirement."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: "Our buyers include kirana chains, distributors, cloud kitchens, hotels, hospitals, facility management companies and corporate procurement teams."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/about",
						children: ["More about ZUCUR MART ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-6 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold text-navy",
						children: "Contact our wholesale desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-5 space-y-4 text-sm",
						children: [
							settings?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `tel:${settings.phone}`,
									className: "hover:text-primary",
									children: settings.phone
								})]
							}) : null,
							settings?.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${settings.email}`,
									className: "break-all hover:text-primary",
									children: settings.email
								})]
							}) : null,
							settings?.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: settings.address
								})]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/contact",
								children: "Contact page"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, { variant: "outline" })]
					})
				]
			})]
		})
	] });
}
function SectionHeading({ eyebrow, title, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xs font-semibold uppercase tracking-[0.25em] text-primary",
			children: eyebrow
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-2 font-display text-2xl font-extrabold text-navy sm:text-3xl",
			children: title
		})] }), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: action.to,
			className: "inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline",
			children: [
				action.label,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
			]
		}) : null]
	});
}
//#endregion
export { HomePage as component };
