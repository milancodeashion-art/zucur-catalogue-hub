import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { G as ArrowRight } from "../_libs/lucide-react.mjs";
import { s as imageSrc } from "./dialog-CGvJfmGP.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as categoriesQuery, l as productsQuery, n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categories.index-CF-E1WKq.js
var import_jsx_runtime = require_jsx_runtime();
function CategoriesPage() {
	const { data: categories = [], isLoading } = useQuery(categoriesQuery);
	const { data: products = [] } = useQuery(productsQuery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Catalogue",
		title: "Wholesale categories",
		subtitle: "Every category is stocked for bulk supply with published minimum order quantities."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-12",
		children: [isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading categories…"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-5 sm:grid-cols-2 lg:grid-cols-3",
			children: categories.map((category) => {
				const count = products.filter((p) => p.category_id === category.id).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/categories/$slug",
					params: { slug: category.slug },
					className: "group overflow-hidden rounded-lg border border-border bg-card shadow-sm transition-shadow hover:shadow-md",
					children: [category.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: imageSrc(category.image) ?? "",
						alt: category.name,
						loading: "lazy",
						className: "aspect-16/9 w-full object-cover transition-transform duration-300 group-hover:scale-105"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg font-bold text-navy group-hover:text-primary",
								children: category.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted-foreground",
								children: category.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary",
								children: [
									count,
									" products ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })
								]
							})
						]
					})]
				}, category.id);
			})
		})]
	})] });
}
//#endregion
export { CategoriesPage as component };
