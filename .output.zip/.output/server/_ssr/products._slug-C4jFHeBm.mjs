import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._slug-C4jFHeBm.js
var $$splitComponentImporter = () => import("./products._slug-DboSqJWJ.mjs");
var Route = createFileRoute("/products/$slug")({
	head: () => ({ meta: [
		{ title: "Wholesale Product Details — ZUCUR MART" },
		{
			name: "description",
			content: "Product specifications, SKU, wholesale price, minimum order quantity and availability. Enquire on WhatsApp or raise a bulk order inquiry."
		},
		{
			property: "og:title",
			content: "Wholesale Product Details — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "SKU, wholesale price, MOQ and availability for bulk buyers."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
