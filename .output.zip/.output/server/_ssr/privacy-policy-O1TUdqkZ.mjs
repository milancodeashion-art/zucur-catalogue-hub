import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-policy-O1TUdqkZ.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Legal",
		title: "Privacy Policy"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-6 px-4 py-12 text-sm leading-relaxed text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-bold text-navy",
				children: "What we collect"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "To access the wholesale catalogue we ask for your full name, phone number and optionally your email address. When you submit a bulk order inquiry we also record your company name, required quantity, delivery location and requirement notes."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-bold text-navy",
				children: "How we use it"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Your details are used only to respond to wholesale enquiries, prepare quotations, confirm stock availability and arrange dispatch. We also keep a record of catalogue enquiries so our team can follow up accurately."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-bold text-navy",
				children: "Sharing"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "We do not sell or rent your information. Details may be shared with logistics partners strictly for delivering a confirmed order."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-bold text-navy",
				children: "WhatsApp enquiries"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Choosing \"Enquire on WhatsApp\" opens WhatsApp with a pre-written message containing the product details and the contact information you provided. Messages sent through WhatsApp are also governed by WhatsApp's own privacy terms."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-bold text-navy",
				children: "Retention and requests"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2",
				children: "Enquiry records are retained for business and tax purposes. To correct or remove your details, contact our wholesale desk and we will action the request."
			})] })
		]
	})] });
}
//#endregion
export { PrivacyPage as component };
