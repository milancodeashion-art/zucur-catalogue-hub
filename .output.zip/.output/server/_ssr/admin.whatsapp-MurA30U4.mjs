import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Pagination } from "./Pagination-fwbkWNUq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.whatsapp-MurA30U4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 15;
function todayISO() {
	const now = /* @__PURE__ */ new Date();
	const offset = now.getTimezoneOffset() * 6e4;
	return new Date(now.getTime() - offset).toISOString().slice(0, 10);
}
function AdminWhatsapp() {
	const today = todayISO();
	const [from, setFrom] = (0, import_react.useState)(today);
	const [to, setTo] = (0, import_react.useState)(today);
	const [sort, setSort] = (0, import_react.useState)("newest");
	const [page, setPage] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [
		from,
		to,
		sort
	]);
	const { data, isLoading } = useQuery({
		queryKey: [
			"admin-whatsapp",
			from,
			to,
			sort,
			page
		],
		queryFn: async () => {
			const start = /* @__PURE__ */ new Date(`${from}T00:00:00`);
			const end = /* @__PURE__ */ new Date(`${to}T23:59:59.999`);
			const offset = (page - 1) * PAGE_SIZE;
			const { data, error, count } = await supabase.from("whatsapp_enquiries").select("id, enquiry_type, created_at, visitors(name, phone), products(name, sku)", { count: "exact" }).gte("created_at", start.toISOString()).lte("created_at", end.toISOString()).order("created_at", { ascending: sort === "oldest" }).range(offset, offset + PAGE_SIZE - 1);
			if (error) throw error;
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	const rows = data?.rows ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-extrabold text-navy",
				children: "WhatsApp enquiry log"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Every \"Enquire on WhatsApp\" and \"Ask When Available\" click. Showing today's logs by default."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 rounded-lg border border-border bg-card p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "w-from",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "w-from",
						type: "date",
						value: from,
						max: to,
						onChange: (e) => setFrom(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "w-to",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "w-to",
						type: "date",
						value: to,
						min: from,
						onChange: (e) => setTo(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "w-sort",
						children: "Sort by date"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "w-sort",
						className: "mt-1 h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm",
						value: sort,
						onChange: (e) => setSort(e.target.value === "oldest" ? "oldest" : "newest"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "newest",
							children: "Newest first"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "oldest",
							children: "Oldest first"
						})]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "w-full",
							onClick: () => {
								setFrom(today);
								setTo(today);
							},
							children: "Today"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "When"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Type"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "SKU"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Visitor"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-6 text-muted-foreground",
							children: "Loading…"
						}) }) : rows.length ? rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: new Date(row.created_at).toLocaleString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: row.enquiry_type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium text-navy",
								children: row.products?.name ?? "General"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: row.products?.sku ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: row.visitors ? `${row.visitors.name} · ${row.visitors.phone}` : "—"
							})
						] }, row.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-6 text-muted-foreground",
							children: "No WhatsApp enquiries in this date range."
						}) })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				page,
				pageSize: PAGE_SIZE,
				total: data?.count ?? 0,
				onPageChange: setPage,
				label: "enquiries"
			})
		]
	});
}
//#endregion
export { AdminWhatsapp as component };
