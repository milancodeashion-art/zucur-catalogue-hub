import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { a as Trash2, d as Plus, m as Pencil, u as Search } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-CGvJfmGP.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Switch, t as ImageUploader } from "./switch-f6_bOPf-.mjs";
import { t as Pagination } from "./Pagination-fwbkWNUq.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.products-yCCZ0D1j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 12;
var EMPTY = {
	name: "",
	slug: "",
	sku: "",
	category_id: "",
	description: "",
	specifications: "",
	price: "",
	discounted_price: "",
	moq: "1",
	stock_status: "available",
	featured: false,
	active: true,
	images: []
};
function slugify(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
var SELECT = "id, name, slug, sku, category_id, description, specifications, price, discounted_price, moq, stock_status, featured, active, created_at, category:categories(name), product_images(image_url, display_order)";
function AdminProducts() {
	const queryClient = useQueryClient();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [term, setTerm] = (0, import_react.useState)("");
	const [search, setSearch] = (0, import_react.useState)("");
	const [stock, setStock] = (0, import_react.useState)("all");
	const [page, setPage] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => setSearch(term.trim()), 300);
		return () => clearTimeout(timer);
	}, [term]);
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [search, stock]);
	const categoryList = useQuery({
		queryKey: ["admin-categories-list"],
		queryFn: async () => {
			const { data, error } = await supabase.from("categories").select("id, name").order("display_order");
			if (error) throw error;
			return data;
		}
	}).data ?? [];
	const products = useQuery({
		queryKey: [
			"admin-products",
			search,
			stock,
			page
		],
		queryFn: async () => {
			let query = supabase.from("products").select(SELECT, { count: "exact" });
			if (stock !== "all") query = query.eq("stock_status", stock);
			if (search) {
				const like = `%${search.replace(/[,()]/g, " ")}%`;
				const parts = [
					`name.ilike.${like}`,
					`sku.ilike.${like}`,
					`description.ilike.${like}`
				];
				const numeric = Number(search);
				if (search !== "" && Number.isFinite(numeric)) parts.push(`price.eq.${numeric}`, `discounted_price.eq.${numeric}`);
				const matchedCategories = categoryList.filter((c) => c.name.toLowerCase().includes(search.toLowerCase())).map((c) => c.id);
				if (matchedCategories.length) parts.push(`category_id.in.(${matchedCategories.join(",")})`);
				query = query.or(parts.join(","));
			}
			const from = (page - 1) * PAGE_SIZE;
			const { data, error, count } = await query.order("created_at", { ascending: false }).range(from, from + PAGE_SIZE - 1);
			if (error) throw error;
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	const save = useMutation({
		mutationFn: async (input) => {
			const price = input.price.trim() === "" ? null : Number(input.price);
			const discounted = input.discounted_price.trim() === "" ? null : Number(input.discounted_price);
			const payload = {
				name: input.name.trim(),
				slug: input.slug.trim() || slugify(input.name),
				sku: input.sku.trim(),
				category_id: input.category_id || null,
				description: input.description.trim() || null,
				specifications: input.specifications.trim() || null,
				price,
				discounted_price: discounted,
				moq: Math.max(1, Number(input.moq) || 1),
				stock_status: input.stock_status,
				featured: input.featured,
				active: input.active
			};
			let productId = input.id;
			if (productId) {
				const { error } = await supabase.from("products").update(payload).eq("id", productId);
				if (error) throw error;
			} else {
				const { data, error } = await supabase.from("products").insert(payload).select("id").single();
				if (error) throw error;
				productId = data.id;
			}
			await supabase.from("product_images").delete().eq("product_id", productId);
			if (input.images.length) {
				const { error } = await supabase.from("product_images").insert(input.images.map((image_url, index) => ({
					product_id: productId,
					image_url,
					display_order: index
				})));
				if (error) throw error;
			}
		},
		onSuccess: () => {
			toast.success("Product saved");
			setDraft(null);
			queryClient.invalidateQueries({ queryKey: ["admin-products"] });
			queryClient.invalidateQueries({ queryKey: ["products"] });
		},
		onError: () => toast.error("Could not save the product. Please check the details and try again.")
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("products").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Product deleted");
			queryClient.invalidateQueries({ queryKey: ["admin-products"] });
			queryClient.invalidateQueries({ queryKey: ["products"] });
		},
		onError: () => toast.error("Could not delete this product. Please try again.")
	});
	const rows = products.data?.rows ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-extrabold text-navy",
					children: "Products"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Add, edit and remove catalogue products."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New product"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 rounded-lg border border-border bg-card p-4 shadow-sm sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: term,
						onChange: (e) => setTerm(e.target.value),
						placeholder: "Search products by name, SKU, price, category…",
						className: "pl-8",
						"aria-label": "Search products"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					"aria-label": "Stock status",
					className: "h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm sm:w-44",
					value: stock,
					onChange: (e) => setStock(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "all",
							children: "All stock status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "available",
							children: "Available"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "stock_out",
							children: "Stock Out"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[900px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Product"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "SKU"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Category"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Price"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Offer"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "MOQ"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Stock"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Flags"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Actions"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: products.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 9,
							className: "px-4 py-6 text-muted-foreground",
							children: "Loading…"
						}) }) : rows.length ? rows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium text-navy",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: p.sku
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-muted-foreground",
								children: p.category?.name ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: p.price ?? "On request"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium text-success",
								children: p.discounted_price ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: p.moq
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: p.stock_status === "stock_out" ? "Stock out" : "Available"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-xs text-muted-foreground",
								children: [p.featured ? "Featured" : null, p.active ? "Active" : "Inactive"].filter(Boolean).join(" · ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setDraft({
											id: p.id,
											name: p.name,
											slug: p.slug,
											sku: p.sku,
											category_id: p.category_id ?? "",
											description: p.description ?? "",
											specifications: p.specifications ?? "",
											price: p.price === null ? "" : String(p.price),
											discounted_price: p.discounted_price === null ? "" : String(p.discounted_price),
											moq: String(p.moq),
											stock_status: p.stock_status === "stock_out" ? "stock_out" : "available",
											featured: p.featured,
											active: p.active,
											images: [...p.product_images ?? []].sort((a, b) => a.display_order - b.display_order).map((img) => img.image_url)
										}),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											if (confirm(`Delete ${p.name}?`)) remove.mutate(p.id);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
									})]
								})
							})
						] }, p.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 9,
							className: "px-4 py-6 text-muted-foreground",
							children: "No products match this search."
						}) })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				page,
				pageSize: PAGE_SIZE,
				total: products.data?.count ?? 0,
				onPageChange: setPage,
				label: "products"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: draft !== null,
				onOpenChange: (open) => !open && setDraft(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] max-w-2xl overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: draft?.id ? "Edit product" : "New product" }) }),
						draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-name",
										children: "Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "p-name",
										value: draft.name,
										onChange: (e) => setDraft({
											...draft,
											name: e.target.value,
											slug: draft.id ? draft.slug : slugify(e.target.value)
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-sku",
									children: "SKU"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-sku",
									value: draft.sku,
									onChange: (e) => setDraft({
										...draft,
										sku: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-slug",
									children: "URL slug"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-slug",
									value: draft.slug,
									onChange: (e) => setDraft({
										...draft,
										slug: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-category",
									children: "Category"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "p-category",
									className: "mt-1 h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm",
									value: draft.category_id,
									onChange: (e) => setDraft({
										...draft,
										category_id: e.target.value
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Uncategorised"
									}), categoryList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: c.id,
										children: c.name
									}, c.id))]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-stock",
									children: "Availability"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "p-stock",
									className: "mt-1 h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm",
									value: draft.stock_status,
									onChange: (e) => setDraft({
										...draft,
										stock_status: e.target.value === "stock_out" ? "stock_out" : "available"
									}),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "available",
										children: "Available"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "stock_out",
										children: "Stock out"
									})]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-price",
									children: "Regular price (blank = on request)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-price",
									type: "number",
									min: "0",
									step: "0.01",
									value: draft.price,
									onChange: (e) => setDraft({
										...draft,
										price: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-discount",
										children: "Discounted price (optional)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "p-discount",
										type: "number",
										min: "0",
										step: "0.01",
										value: draft.discounted_price,
										onChange: (e) => setDraft({
											...draft,
											discounted_price: e.target.value
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: "Leave blank for no offer. Must not exceed the regular price."
									})
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "p-moq",
									children: "MOQ"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "p-moq",
									type: "number",
									min: "1",
									value: draft.moq,
									onChange: (e) => setDraft({
										...draft,
										moq: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-desc",
										children: "Description"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "p-desc",
										rows: 3,
										value: draft.description,
										onChange: (e) => setDraft({
											...draft,
											description: e.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-specs",
										children: "Specifications"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "p-specs",
										rows: 3,
										value: draft.specifications,
										onChange: (e) => setDraft({
											...draft,
											specifications: e.target.value
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "sm:col-span-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
										label: "Product images (first image is the main image)",
										folder: "products",
										multiple: true,
										value: draft.images,
										onChange: (images) => setDraft({
											...draft,
											images
										})
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "p-featured",
										checked: draft.featured,
										onCheckedChange: (v) => setDraft({
											...draft,
											featured: v
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-featured",
										children: "Featured"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "p-active",
										checked: draft.active,
										onCheckedChange: (v) => setDraft({
											...draft,
											active: v
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "p-active",
										children: "Active"
									})]
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDraft(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: save.isPending,
							onClick: () => {
								if (!draft) return;
								if (!draft.name.trim() || !draft.sku.trim()) {
									toast.error("Name and SKU are required");
									return;
								}
								const price = draft.price.trim() === "" ? null : Number(draft.price);
								const discounted = draft.discounted_price.trim() === "" ? null : Number(draft.discounted_price);
								if (discounted !== null) {
									if (!Number.isFinite(discounted) || discounted < 0) {
										toast.error("Discounted price must be a positive number.");
										return;
									}
									if (price === null) {
										toast.error("Add a regular price before setting a discounted price.");
										return;
									}
									if (discounted > price) {
										toast.error("Discounted price cannot be greater than the regular price.");
										return;
									}
								}
								save.mutate(draft);
							},
							children: save.isPending ? "Saving…" : "Save product"
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { AdminProducts as component };
