import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { O as ImageOff } from "../_libs/lucide-react.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as formatPrice, o as hasDiscount, s as productImage, u as settingsQuery } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
import { n as StockBadge, t as MoqBadge } from "./badges-B8CbVee5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ProductCard-VzGlFIrQ.js
var import_jsx_runtime = require_jsx_runtime();
function PriceTag({ product, currency = "INR", size = "sm", className }) {
	const discounted = hasDiscount(product);
	const main = discounted ? product.discounted_price : product.price;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("flex flex-wrap items-baseline gap-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("font-display font-extrabold", size === "lg" ? "text-3xl" : "text-lg", discounted ? "text-success" : "text-navy"),
			children: formatPrice(main ?? null, currency)
		}), discounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-muted-foreground line-through", size === "lg" ? "text-base" : "text-sm"),
			children: formatPrice(product.price, currency)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "rounded bg-gold px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-gold-foreground",
			children: "Offer"
		})] }) : null]
	});
}
function ProductCard({ product }) {
	const { data: settings } = useQuery(settingsQuery);
	const image = productImage(product);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex h-full flex-col overflow-hidden rounded-lg border border-border bg-card shadow-sm transition-shadow hover:shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/products/$slug",
			params: { slug: product.slug },
			className: "relative block aspect-4/3 overflow-hidden bg-secondary",
			children: [image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: image,
				alt: product.name,
				loading: "lazy",
				className: "size-full object-cover transition-transform duration-300 group-hover:scale-105"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-full place-items-center text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "size-8" })
			}), product.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute left-2 top-2 rounded bg-gold px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-gold-foreground",
				children: "Featured"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] font-semibold uppercase tracking-wide text-primary",
					children: product.category?.name ?? "Wholesale"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products/$slug",
					params: { slug: product.slug },
					className: "font-display text-sm font-bold leading-snug text-navy hover:text-primary sm:text-base",
					children: product.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["SKU: ", product.sku]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceTag, {
					product,
					currency: settings?.currency ?? "INR",
					className: "mt-auto"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoqBadge, { moq: product.moq }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockBadge, { status: product.stock_status })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {
						product,
						size: "sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/bulk-order-inquiry",
							search: { product: product.slug },
							className: "w-full justify-center",
							children: "Bulk Order Inquiry"
						})
					})]
				})
			]
		})]
	});
}
//#endregion
export { ProductCard as n, PriceTag as t };
