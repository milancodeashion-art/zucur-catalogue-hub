import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categories._slug-DqAM6qav.js
var $$splitComponentImporter = () => import("./categories._slug-niwKeksT.mjs");
var Route = createFileRoute("/categories/$slug")({
	head: () => ({ meta: [
		{ title: "Category — Wholesale Products | ZUCUR MART" },
		{
			name: "description",
			content: "Wholesale products in this category with SKU, price, minimum order quantity and stock availability."
		},
		{
			property: "og:title",
			content: "Wholesale Category — ZUCUR MART"
		},
		{
			property: "og:description",
			content: "Bulk-rate products with MOQ and availability at ZUCUR MART."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
