import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { K as ArrowLeft, O as ImageOff, c as ShieldCheck, r as Truck } from "../_libs/lucide-react.mjs";
import { s as imageSrc } from "./dialog-CGvJfmGP.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as productQuery, l as productsQuery, n as SiteLayout, u as settingsQuery } from "./SiteLayout-DQjmCaE1.mjs";
import { t as WhatsappEnquiryButton } from "./WhatsappEnquiryButton-VXYHipoX.mjs";
import { n as StockBadge, t as MoqBadge } from "./badges-B8CbVee5.mjs";
import { n as ProductCard, t as PriceTag } from "./ProductCard-VzGlFIrQ.mjs";
import { t as Route } from "./products._slug-C4jFHeBm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products._slug-DboSqJWJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductDetailPage() {
	const { slug } = Route.useParams();
	const { data: product, isLoading } = useQuery(productQuery(slug));
	const { data: settings } = useQuery(settingsQuery);
	const { data: allProducts = [] } = useQuery(productsQuery);
	const [activeImage, setActiveImage] = (0, import_react.useState)(0);
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-7xl px-4 py-20 text-sm text-muted-foreground",
		children: "Loading product…"
	}) });
	if (!product) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-extrabold text-navy",
				children: "Product not available"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "This listing may have been removed from the wholesale catalogue."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/products",
					children: "Back to catalogue"
				})
			})
		]
	}) });
	const images = [...product.product_images ?? []].sort((a, b) => a.display_order - b.display_order);
	const related = allProducts.filter((item) => item.category_id === product.category_id && item.id !== product.id).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-7xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/products",
				className: "inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Back to all products"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-lg border border-border bg-card",
					children: images[activeImage] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: imageSrc(images[activeImage].image_url) ?? "",
						alt: product.name,
						className: "aspect-4/3 w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid aspect-4/3 w-full place-items-center bg-secondary text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "size-10" })
					})
				}), images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: images.map((image, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActiveImage(index),
						className: `size-16 overflow-hidden rounded-md border ${index === activeImage ? "border-primary ring-2 ring-primary/30" : "border-border"}`,
						"aria-label": `View image ${index + 1}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: imageSrc(image.image_url) ?? "",
							alt: "",
							className: "size-full object-cover"
						})
					}, image.image_url + index))
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					product.category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/categories/$slug",
						params: { slug: product.category.slug },
						className: "text-xs font-semibold uppercase tracking-wide text-primary hover:underline",
						children: product.category.name
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-2xl font-extrabold text-navy sm:text-3xl",
						children: product.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: ["SKU: ", product.sku]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceTag, {
							product,
							currency: settings?.currency ?? "INR",
							size: "lg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground",
							children: "per unit · wholesale"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoqBadge, { moq: product.moq }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockBadge, { status: product.stock_status })]
					}),
					product.stock_status === "stock_out" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive",
						children: "This item is currently out of stock. Ask us when it will be available and we will confirm the next dispatch batch."
					}) : null,
					product.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-sm leading-relaxed text-muted-foreground",
						children: product.description
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsappEnquiryButton, {
							product,
							size: "lg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "outline",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/bulk-order-inquiry",
								search: { product: product.slug },
								children: "Bulk Order Inquiry"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 grid gap-3 text-sm text-muted-foreground sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "mt-0.5 size-4 shrink-0 text-primary" }), "Pan-India dispatch on confirmed quotations"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mt-0.5 size-4 shrink-0 text-primary" }), "GST invoice with every wholesale order"]
						})]
					}),
					product.specifications ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 rounded-lg border border-border bg-card p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-base font-bold text-navy",
							children: "Specifications"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 grid gap-2 text-sm text-muted-foreground",
							children: product.specifications.split("|").map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-border pb-2 last:border-0 last:pb-0",
								children: line.trim()
							}, line))
						})]
					}) : null
				] })]
			}),
			related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-xl font-extrabold text-navy",
					children: ["More from ", product.category?.name ?? "this category"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product: item }, item.id))
				})]
			}) : null
		]
	}) });
}
//#endregion
export { ProductDetailPage as component };
