import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { M as Eye, O as ImageOff, a as Trash2, d as Plus, m as Pencil } from "../_libs/lucide-react.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as imageSrc, t as Dialog } from "./dialog-CGvJfmGP.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Switch, t as ImageUploader } from "./switch-f6_bOPf-.mjs";
import { t as Pagination } from "./Pagination-fwbkWNUq.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.banners-CX0pHvWF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 10;
var EMPTY = {
	image: "",
	title: "",
	description: "",
	button_text: "",
	button_link: "",
	display_order: "0",
	active: true
};
function AdminBanners() {
	const queryClient = useQueryClient();
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(1);
	const [deleteId, setDeleteId] = (0, import_react.useState)(null);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const banners = useQuery({
		queryKey: ["admin-banners", page],
		queryFn: async () => {
			const from = (page - 1) * PAGE_SIZE;
			const { data, error, count } = await supabase.from("banners").select("*", { count: "exact" }).order("display_order", { ascending: true }).range(from, from + PAGE_SIZE - 1);
			if (error) throw error;
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	(0, import_react.useEffect)(() => {
		const total = banners.data?.count ?? 0;
		const pageCount = Math.max(1, Math.ceil(total / PAGE_SIZE));
		if (page > pageCount) setPage(pageCount);
	}, [banners.data?.count, page]);
	function invalidate() {
		queryClient.invalidateQueries({ queryKey: ["admin-banners"] });
		queryClient.invalidateQueries({ queryKey: ["banners"] });
	}
	const save = useMutation({
		mutationFn: async (input) => {
			const payload = {
				image: input.image,
				title: input.title.trim() || null,
				description: input.description.trim() || null,
				button_text: input.button_text.trim() || null,
				button_link: input.button_link.trim() || null,
				display_order: Number(input.display_order) || 0,
				active: input.active
			};
			if (input.id) {
				const { error } = await supabase.from("banners").update(payload).eq("id", input.id);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("banners").insert(payload);
				if (error) throw error;
			}
		},
		onSuccess: () => {
			toast.success("Banner saved");
			setDraft(null);
			invalidate();
		},
		onError: () => toast.error("Banner could not be saved. Please try again.")
	});
	const toggle = useMutation({
		mutationFn: async (input) => {
			const { error } = await supabase.from("banners").update({ active: input.active }).eq("id", input.id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Banner status updated");
			invalidate();
		},
		onError: () => toast.error("Could not update the banner status. Please try again.")
	});
	const remove = useMutation({
		mutationFn: async (id) => {
			const { error } = await supabase.from("banners").delete().eq("id", id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Banner deleted");
			setDeleteId(null);
			invalidate();
		},
		onError: () => toast.error("Could not delete this banner. Please try again.")
	});
	const rows = banners.data?.rows ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-extrabold text-navy",
					children: "Banners"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Manage the homepage banner slider. Only active banners appear, in display order."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setDraft({ ...EMPTY }),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add banner"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border bg-card shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[760px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-muted/60 text-left text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Preview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Banner"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: "Display order"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right",
								children: "Actions"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: banners.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-6 text-muted-foreground",
							children: "Loading…"
						}) }) : rows.length ? rows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: b.image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: imageSrc(b.image) ?? "",
									alt: b.title ?? "Banner",
									className: "h-14 w-24 rounded-md border border-border object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-14 w-24 place-items-center rounded-md bg-secondary text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageOff, { className: "size-5" })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium text-navy",
									children: b.title ?? "Untitled banner"
								}), b.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 line-clamp-1 max-w-xs text-xs text-muted-foreground",
									children: b.description
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: b.active ? "rounded bg-success/15 px-2 py-0.5 text-xs font-semibold text-success" : "rounded bg-muted px-2 py-0.5 text-xs font-semibold text-muted-foreground",
									children: b.active ? "Active" : "Inactive"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: b.display_order
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap justify-end gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setPreview(imageSrc(b.image) ?? ""),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => toggle.mutate({
												id: b.id,
												active: !b.active
											}),
											children: b.active ? "Deactivate" : "Activate"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setDraft({
												id: b.id,
												image: b.image,
												title: b.title ?? "",
												description: b.description ?? "",
												button_text: b.button_text ?? "",
												button_link: b.button_link ?? "",
												display_order: String(b.display_order),
												active: b.active
											}),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setDeleteId(b.id),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
										})
									]
								})
							})
						] }, b.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "px-4 py-6 text-muted-foreground",
							children: "No banners yet. Add your first homepage banner."
						}) })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				page,
				pageSize: PAGE_SIZE,
				total: banners.data?.count ?? 0,
				onPageChange: setPage,
				label: "banners"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: draft !== null,
				onOpenChange: (open) => !open && setDraft(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-h-[90vh] max-w-xl overflow-y-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: draft?.id ? "Edit banner" : "Add banner" }) }),
						draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploader, {
									label: "Banner image",
									folder: "banners",
									value: draft.image ? [draft.image] : [],
									onChange: (urls) => setDraft({
										...draft,
										image: urls[0] ?? ""
									}),
									hint: "Wide landscape images work best · JPG, PNG, WEBP up to 10 MB."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "b-title",
									children: "Title (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "b-title",
									value: draft.title,
									maxLength: 120,
									onChange: (e) => setDraft({
										...draft,
										title: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "b-desc",
									children: "Description (optional)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "b-desc",
									rows: 2,
									maxLength: 300,
									value: draft.description,
									onChange: (e) => setDraft({
										...draft,
										description: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "b-btn",
										children: "Button text (optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "b-btn",
										value: draft.button_text,
										maxLength: 40,
										onChange: (e) => setDraft({
											...draft,
											button_text: e.target.value
										})
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "b-link",
										children: "Button link (optional)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "b-link",
										value: draft.button_link,
										placeholder: "/products",
										onChange: (e) => setDraft({
											...draft,
											button_link: e.target.value
										})
									})] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "b-order",
									children: "Display order"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "b-order",
									type: "number",
									value: draft.display_order,
									onChange: (e) => setDraft({
										...draft,
										display_order: e.target.value
									})
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										id: "b-active",
										checked: draft.active,
										onCheckedChange: (v) => setDraft({
											...draft,
											active: v
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "b-active",
										children: "Active on homepage"
									})]
								})
							]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setDraft(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: save.isPending,
							onClick: () => {
								if (!draft) return;
								if (!draft.image) {
									toast.error("Please upload a banner image first.");
									return;
								}
								save.mutate(draft);
							},
							children: save.isPending ? "Saving…" : "Save banner"
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: deleteId !== null,
				onOpenChange: (open) => !open && setDeleteId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Delete banner" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Are you sure you want to delete this banner? This cannot be undone." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => setDeleteId(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "destructive",
						disabled: remove.isPending,
						onClick: () => deleteId && remove.mutate(deleteId),
						children: remove.isPending ? "Deleting…" : "Delete banner"
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: preview !== null,
				onOpenChange: (open) => !open && setPreview(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Banner preview" }) }), preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "Banner preview",
						className: "max-h-[70vh] w-full rounded-lg object-contain"
					}) : null]
				})
			})
		]
	});
}
//#endregion
export { AdminBanners as component };
