import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as categoriesQuery, l as productsQuery, n as SiteLayout, t as PageHeader } from "./SiteLayout-DQjmCaE1.mjs";
import { t as Route } from "./categories._slug-DqAM6qav.mjs";
import { n as ProductCard } from "./ProductCard-VzGlFIrQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categories._slug-niwKeksT.js
var import_jsx_runtime = require_jsx_runtime();
function CategoryDetailPage() {
	const { slug } = Route.useParams();
	const { data: categories = [] } = useQuery(categoriesQuery);
	const { data: products = [], isLoading } = useQuery(productsQuery);
	const category = categories.find((c) => c.slug === slug);
	const items = category ? products.filter((p) => p.category_id === category.id) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		eyebrow: "Category",
		title: category?.name ?? "Category",
		subtitle: category?.description ?? void 0
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-7xl px-4 py-12",
		children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Loading products…"
		}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg border border-border bg-card p-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-bold text-navy",
					children: "No products listed yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Tell us what you need and we will source it for your volume."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/bulk-order-inquiry",
						children: "Send a bulk inquiry"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
			children: items.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
		})
	})] });
}
//#endregion
export { CategoryDetailPage as component };
