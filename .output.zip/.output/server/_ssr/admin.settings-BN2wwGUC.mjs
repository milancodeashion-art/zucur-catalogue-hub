import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.settings-BN2wwGUC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY = {
	business_name: "",
	whatsapp_number: "",
	email: "",
	phone: "",
	address: "",
	business_hours: "",
	default_whatsapp_message: "",
	currency: "INR"
};
function AdminSettings() {
	const queryClient = useQueryClient();
	const [form, setForm] = (0, import_react.useState)(EMPTY);
	const settings = useQuery({
		queryKey: ["admin-settings"],
		queryFn: async () => {
			const { data, error } = await supabase.from("site_settings").select("*").limit(1).maybeSingle();
			if (error) throw error;
			return data;
		}
	});
	(0, import_react.useEffect)(() => {
		const data = settings.data;
		if (!data) return;
		setForm({
			business_name: data.business_name ?? "",
			whatsapp_number: data.whatsapp_number ?? "",
			email: data.email ?? "",
			phone: data.phone ?? "",
			address: data.address ?? "",
			business_hours: data.business_hours ?? "",
			default_whatsapp_message: data.default_whatsapp_message ?? "",
			currency: data.currency ?? "INR"
		});
	}, [settings.data]);
	const save = useMutation({
		mutationFn: async () => {
			const payload = {
				business_name: form.business_name.trim() || "ZUCUR MART",
				whatsapp_number: form.whatsapp_number.replace(/[^0-9]/g, ""),
				email: form.email.trim() || null,
				phone: form.phone.trim() || null,
				address: form.address.trim() || null,
				business_hours: form.business_hours.trim() || null,
				default_whatsapp_message: form.default_whatsapp_message.trim() || null,
				currency: form.currency.trim() || "INR"
			};
			const existingId = settings.data?.id;
			if (existingId) {
				const { error } = await supabase.from("site_settings").update(payload).eq("id", existingId);
				if (error) throw error;
			} else {
				const { error } = await supabase.from("site_settings").insert(payload);
				if (error) throw error;
			}
		},
		onSuccess: () => {
			toast.success("Settings saved");
			queryClient.invalidateQueries({ queryKey: ["admin-settings"] });
			queryClient.invalidateQueries({ queryKey: ["site-settings"] });
		},
		onError: (error) => toast.error(error.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl font-extrabold text-navy",
			children: "Site settings"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Business WhatsApp number and contact details shown across the site."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-lg border border-border bg-card p-5 shadow-sm sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-name",
					children: "Business name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-name",
					value: form.business_name,
					onChange: (e) => setForm({
						...form,
						business_name: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-wa",
					children: "WhatsApp number (country code, digits only)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-wa",
					value: form.whatsapp_number,
					onChange: (e) => setForm({
						...form,
						whatsapp_number: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-email",
					children: "Email"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-email",
					type: "email",
					value: form.email,
					onChange: (e) => setForm({
						...form,
						email: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-phone",
					children: "Phone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-phone",
					value: form.phone,
					onChange: (e) => setForm({
						...form,
						phone: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-hours",
					children: "Business hours"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-hours",
					value: form.business_hours,
					onChange: (e) => setForm({
						...form,
						business_hours: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "s-currency",
					children: "Currency"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "s-currency",
					value: form.currency,
					onChange: (e) => setForm({
						...form,
						currency: e.target.value
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "s-address",
						children: "Address"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "s-address",
						rows: 2,
						value: form.address,
						onChange: (e) => setForm({
							...form,
							address: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "s-msg",
						children: "Default WhatsApp message"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "s-msg",
						rows: 3,
						value: form.default_whatsapp_message,
						onChange: (e) => setForm({
							...form,
							default_whatsapp_message: e.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						disabled: save.isPending,
						onClick: () => save.mutate(),
						children: save.isPending ? "Saving…" : "Save settings"
					})
				})
			]
		})]
	});
}
//#endregion
export { AdminSettings as component };
