import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { a as useQueryClient, r as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Pagination } from "./Pagination-fwbkWNUq.mjs";
import { t as Textarea } from "./textarea-DBn9CRiI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.inquiries-Ckovy37k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"New",
	"Contacted",
	"In Progress",
	"Completed",
	"Cancelled"
];
var PAGE_SIZE = 12;
function AdminInquiries() {
	const queryClient = useQueryClient();
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [page, setPage] = (0, import_react.useState)(1);
	const [notes, setNotes] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [filter]);
	const inquiries = useQuery({
		queryKey: [
			"admin-inquiries",
			filter,
			page
		],
		queryFn: async () => {
			let query = supabase.from("bulk_order_inquiries").select("*", { count: "exact" });
			if (filter !== "All") query = query.eq("status", filter);
			const from = (page - 1) * PAGE_SIZE;
			const { data, error, count } = await query.order("created_at", { ascending: false }).range(from, from + PAGE_SIZE - 1);
			if (error) throw error;
			return {
				rows: data ?? [],
				count: count ?? 0
			};
		}
	});
	const update = useMutation({
		mutationFn: async (input) => {
			const patch = {};
			if (input.status !== void 0) patch.status = input.status;
			if (input.admin_notes !== void 0) patch.admin_notes = input.admin_notes;
			const { error } = await supabase.from("bulk_order_inquiries").update(patch).eq("id", input.id);
			if (error) throw error;
		},
		onSuccess: () => {
			toast.success("Inquiry updated");
			queryClient.invalidateQueries({ queryKey: ["admin-inquiries"] });
		},
		onError: (error) => toast.error(error.message)
	});
	const rows = inquiries.data?.rows ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-extrabold text-navy",
				children: "Bulk order inquiries"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Track and progress every wholesale enquiry."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: ["All", ...STATUSES].map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: filter === status ? "default" : "outline",
					onClick: () => setFilter(status),
					children: status
				}, status))
			}),
			inquiries.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Loading…"
			}) : rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border bg-card p-4 shadow-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-base font-bold text-navy",
								children: [row.product_name ?? "General enquiry", row.product_sku ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs font-medium text-muted-foreground",
									children: row.product_sku
								}) : null]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									row.required_quantity,
									" units · ",
									row.customer_name,
									row.company_name ? ` · ${row.company_name}` : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: [
									row.customer_phone,
									row.customer_email ? ` · ${row.customer_email}` : "",
									row.delivery_location ? ` · ${row.delivery_location}` : ""
								]
							}),
							row.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-2xl text-sm text-foreground",
								children: row.message
							}) : null
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: new Date(row.created_at).toLocaleString()
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-9 rounded-md border border-input bg-transparent px-3 text-sm",
								value: row.status,
								onChange: (e) => update.mutate({
									id: row.id,
									status: e.target.value
								}),
								children: STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: status,
									children: status
								}, status))
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							placeholder: "Internal notes",
							value: notes[row.id] ?? row.admin_notes ?? "",
							onChange: (e) => setNotes({
								...notes,
								[row.id]: e.target.value
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => update.mutate({
									id: row.id,
									admin_notes: notes[row.id] ?? row.admin_notes ?? ""
								}),
								children: "Save notes"
							})
						})]
					})]
				}, row.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No inquiries in this view."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
				page,
				pageSize: PAGE_SIZE,
				total: inquiries.data?.count ?? 0,
				onPageChange: setPage,
				label: "inquiries"
			})
		]
	});
}
//#endregion
export { AdminInquiries as component };
