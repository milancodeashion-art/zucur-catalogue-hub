import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-DRsC1qZi.mjs";
import { t as supabase } from "./client-MltmUiWg.mjs";
import { n as useVisitor } from "./visitor-CyHULbu_.mjs";
import { n as Label, t as Input } from "./input-CoDpKGui.mjs";
import { N as Clock, b as MapPin, c as ShieldCheck, f as Phone, t as X, u as Search, x as Mail, y as Menu } from "../_libs/lucide-react.mjs";
import { n as DialogContent, o as DialogTitle, r as DialogDescription, s as imageSrc, t as Dialog } from "./dialog-CGvJfmGP.mjs";
import { t as zucur_logo_default } from "./zucur_logo-BL-P8Q7S.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as queryOptions, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SiteLayout-DQjmCaE1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRODUCT_SELECT = "id, category_id, name, slug, sku, description, specifications, price, discounted_price, moq, stock_status, featured, active, created_at, category:categories(name, slug), product_images(image_url, display_order)";
function unwrap(data) {
	return data;
}
var categoriesQuery = queryOptions({
	queryKey: ["categories"],
	queryFn: async () => {
		const { data, error } = await supabase.from("categories").select("id, name, slug, description, image, display_order, active").eq("active", true).order("display_order", { ascending: true });
		if (error) throw error;
		return unwrap(data ?? []);
	}
});
var productsQuery = queryOptions({
	queryKey: ["products"],
	queryFn: async () => {
		const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).eq("active", true).order("created_at", { ascending: false });
		if (error) throw error;
		return unwrap(data ?? []);
	}
});
function productQuery(slug) {
	return queryOptions({
		queryKey: ["product", slug],
		queryFn: async () => {
			const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).eq("slug", slug).eq("active", true).maybeSingle();
			if (error) throw error;
			return data ? unwrap(data) : null;
		}
	});
}
var settingsQuery = queryOptions({
	queryKey: ["site-settings"],
	queryFn: async () => {
		const { data, error } = await supabase.from("site_settings").select("id, business_name, whatsapp_number, email, phone, address, business_hours, default_whatsapp_message, currency").limit(1).maybeSingle();
		if (error) throw error;
		return data ? unwrap(data) : null;
	}
});
function productImage(product) {
	const sorted = [...product.product_images ?? []].sort((a, b) => a.display_order - b.display_order);
	return imageSrc(sorted[0]?.image_url ?? null);
}
function formatPrice(price, currency = "INR") {
	if (price === null || price === void 0) return "Price on request";
	return `${currency === "INR" ? "₹" : currency === "USD" ? "$" : `${currency} `}${Number(price).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}
function hasDiscount(product) {
	return product.discounted_price !== null && product.discounted_price !== void 0 && product.price !== null && product.price !== void 0 && product.discounted_price < product.price;
}
var bannersQuery = queryOptions({
	queryKey: ["banners"],
	queryFn: async () => {
		const { data, error } = await supabase.from("banners").select("id, image, title, description, button_text, button_link, display_order, active").eq("active", true).order("display_order", { ascending: true });
		if (error) throw error;
		return unwrap(data ?? []);
	}
});
function digitsOnly$1(value) {
	return value.replace(/\D/g, "");
}
function SocialIcon$1({ path, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		fill: "currentColor",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: path })
	});
}
var SOCIALS$1 = [
	{
		label: "Telegram",
		href: "https://t.me/Newindiacart",
		color: "#229ED9",
		path: "M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 15.3l-1.99 1.93c-.23.23-.42.42-.83.42z"
	},
	{
		label: "Instagram",
		href: "https://www.instagram.com/zucur.mart?stkn=NXRrbjR0dmxtNTdk",
		color: "#E4405F",
		path: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.43.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.43.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.43-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.43-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16zm0 1.62c-3.15 0-3.5.01-4.74.07-1.14.05-1.76.24-2.17.4-.55.21-.94.47-1.35.88-.41.41-.67.8-.88 1.35-.16.41-.35 1.03-.4 2.17-.06 1.24-.07 1.59-.07 4.74s.01 3.5.07 4.74c.05 1.14.24 1.76.4 2.17.21.55.47.94.88 1.35.41.41.8.67 1.35.88.41.16 1.03.35 2.17.4 1.24.06 1.59.07 4.74.07s3.5-.01 4.74-.07c1.14-.05 1.76-.24 2.17-.4.55-.21.94-.47 1.35-.88.41-.41.67-.8.88-1.35.16-.41.35-1.03.4-2.17.06-1.24.07-1.59.07-4.74s-.01-3.5-.07-4.74c-.05-1.14-.24-1.76-.4-2.17a3.6 3.6 0 0 0-.88-1.35 3.6 3.6 0 0 0-1.35-.88c-.41-.16-1.03-.35-2.17-.4-1.24-.06-1.59-.07-4.74-.07zm0 2.76a5.4 5.4 0 1 1 0 10.8 5.4 5.4 0 0 1 0-10.8zm0 1.62a3.78 3.78 0 1 0 0 7.56 3.78 3.78 0 0 0 0-7.56zm5.6-3.39a1.26 1.26 0 1 1 0 2.52 1.26 1.26 0 0 1 0-2.52z"
	},
	{
		label: "YouTube",
		href: "https://youtube.com/@zucurstore?si=CsGQLlbgf_ovwsiy",
		color: "#FF0000",
		path: "M23.5 6.2a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 0 0 .5 6.2C0 8.07 0 12 0 12s0 3.93.5 5.8a3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z"
	}
];
var WHATSAPP_PATH$1 = "M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2zm5.8 14.13c-.24.68-1.4 1.31-1.95 1.38-.5.07-1.13.1-1.82-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3 0-1.43.75-2.13 1.02-2.42.27-.29.58-.36.78-.36.19 0 .39 0 .56.01.18.01.42-.07.66.5.24.68.82 2.35.89 2.52.07.17.12.37.02.57-.09.2-.14.32-.28.49-.14.17-.29.38-.42.51-.14.14-.28.29-.12.57.16.28.7 1.16 1.5 1.88 1.03.92 1.9 1.2 2.18 1.34.27.14.43.12.59-.07.16-.2.68-.79.86-1.06.18-.27.36-.23.61-.14.25.09 1.58.75 1.85.88.27.14.45.2.52.31.07.11.07.65-.17 1.33z";
function FloatingSocialBar() {
	const { data: settings } = useQuery(settingsQuery);
	const whatsappNumber = settings?.whatsapp_number;
	const links = [...SOCIALS$1, ...whatsappNumber ? [{
		label: "WhatsApp",
		href: `https://wa.me/${digitsOnly$1(whatsappNumber)}`,
		color: "#25D366",
		path: WHATSAPP_PATH$1
	}] : []];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed bottom-4 right-4 z-50 flex flex-col gap-2 sm:bottom-6 sm:right-6",
		children: links.map((social) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: social.href,
			target: "_blank",
			rel: "noopener noreferrer",
			"aria-label": social.label,
			title: social.label,
			style: { backgroundColor: social.color },
			className: "group/social grid size-10 place-items-center rounded-full shadow-lg ring-1 ring-black/5 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60 sm:size-11",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon$1, {
				path: social.path,
				className: "size-[18px] text-white transition-transform duration-200 group-hover/social:scale-110 sm:size-5"
			})
		}, social.label))
	});
}
function digitsOnly(value) {
	return value.replace(/\D/g, "");
}
function SocialIcon({ path, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className,
		fill: "currentColor",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: path })
	});
}
var SOCIALS = [
	{
		label: "Telegram",
		href: "https://t.me/Newindiacart",
		color: "#229ED9",
		path: "M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 15.3l-1.99 1.93c-.23.23-.42.42-.83.42z"
	},
	{
		label: "Instagram",
		href: "https://www.instagram.com/zucur.mart?stkn=NXRrbjR0dmxtNTdk",
		color: "#E4405F",
		path: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.43.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.43.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.43-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.43-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16zm0 1.62c-3.15 0-3.5.01-4.74.07-1.14.05-1.76.24-2.17.4-.55.21-.94.47-1.35.88-.41.41-.67.8-.88 1.35-.16.41-.35 1.03-.4 2.17-.06 1.24-.07 1.59-.07 4.74s.01 3.5.07 4.74c.05 1.14.24 1.76.4 2.17.21.55.47.94.88 1.35.41.41.8.67 1.35.88.41.16 1.03.35 2.17.4 1.24.06 1.59.07 4.74.07s3.5-.01 4.74-.07c1.14-.05 1.76-.24 2.17-.4.55-.21.94-.47 1.35-.88.41-.41.67-.8.88-1.35.16-.41.35-1.03.4-2.17.06-1.24.07-1.59.07-4.74s-.01-3.5-.07-4.74c-.05-1.14-.24-1.76-.4-2.17a3.6 3.6 0 0 0-.88-1.35 3.6 3.6 0 0 0-1.35-.88c-.41-.16-1.03-.35-2.17-.4-1.24-.06-1.59-.07-4.74-.07zm0 2.76a5.4 5.4 0 1 1 0 10.8 5.4 5.4 0 0 1 0-10.8zm0 1.62a3.78 3.78 0 1 0 0 7.56 3.78 3.78 0 0 0 0-7.56zm5.6-3.39a1.26 1.26 0 1 1 0 2.52 1.26 1.26 0 0 1 0-2.52z"
	},
	{
		label: "YouTube",
		href: "https://youtube.com/@zucurstore?si=CsGQLlbgf_ovwsiy",
		color: "#FF0000",
		path: "M23.5 6.2a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.51A3.02 3.02 0 0 0 .5 6.2C0 8.07 0 12 0 12s0 3.93.5 5.8a3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z"
	}
];
var WHATSAPP_PATH = "M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2zm5.8 14.13c-.24.68-1.4 1.31-1.95 1.38-.5.07-1.13.1-1.82-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.17-4.95-4.37-.14-.2-1.18-1.57-1.18-3 0-1.43.75-2.13 1.02-2.42.27-.29.58-.36.78-.36.19 0 .39 0 .56.01.18.01.42-.07.66.5.24.68.82 2.35.89 2.52.07.17.12.37.02.57-.09.2-.14.32-.28.49-.14.17-.29.38-.42.51-.14.14-.28.29-.12.57.16.28.7 1.16 1.5 1.88 1.03.92 1.9 1.2 2.18 1.34.27.14.43.12.59-.07.16-.2.68-.79.86-1.06.18-.27.36-.23.61-.14.25.09 1.58.75 1.85.88.27.14.45.2.52.31.07.11.07.65-.17 1.33z";
function SiteFooter() {
	const { data: settings } = useQuery(settingsQuery);
	const { data: categories } = useQuery(categoriesQuery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-16 bg-navy text-navy-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-9 place-items-center overflow-hidden rounded-md bg-white p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: zucur_logo_default,
								alt: "ZUCUR MART logo",
								className: "h-full w-full rounded-[6px] object-contain"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-extrabold",
							children: "ZUCUR MART"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-navy-foreground/70",
						children: "A B2B wholesale supply house serving retailers, distributors, hotels and institutions with bulk-rate packaging, hygiene, disposables and office essentials."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs uppercase tracking-[0.2em] text-gold",
						children: "Wholesale enquiries only"
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-sm font-bold uppercase tracking-wider text-gold",
					children: "Categories"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: (categories ?? []).slice(0, 6).map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/categories/$slug",
						params: { slug: category.slug },
						className: "text-navy-foreground/75 transition-colors hover:text-gold",
						children: category.name
					}) }, category.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-sm font-bold uppercase tracking-wider text-gold",
					children: "Company"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/about",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "About Us"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/products",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "All Products"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/bulk-order-inquiry",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "Bulk Order Inquiry"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "Contact"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privacy-policy",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "Privacy Policy"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/terms",
							className: "text-navy-foreground/75 hover:text-gold",
							children: "Terms & Conditions"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-sm font-bold uppercase tracking-wider text-gold",
						children: "Get in touch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-3 text-sm text-navy-foreground/75",
						children: [
							settings?.address ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: settings.address })]
							}) : null,
							settings?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `tel:${settings.phone}`,
									className: "hover:text-gold",
									children: settings.phone
								})]
							}) : null,
							settings?.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: `mailto:${settings.email}`,
									className: "break-all hover:text-gold",
									children: settings.email
								})]
							}) : null,
							settings?.business_hours ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "mt-0.5 size-4 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: settings.business_hours })]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-center gap-3",
						children: [SOCIALS.map((social) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: social.href,
							target: "_blank",
							rel: "noopener noreferrer",
							"aria-label": social.label,
							style: { backgroundColor: social.color },
							className: "group/social grid size-9 place-items-center rounded-full shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
								path: social.path,
								className: "size-[18px] text-white transition-transform duration-200 group-hover/social:scale-110"
							})
						}, social.label)), settings?.whatsapp_number ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `https://wa.me/${digitsOnly(settings.whatsapp_number)}`,
							target: "_blank",
							rel: "noopener noreferrer",
							"aria-label": "WhatsApp",
							style: { backgroundColor: "#25D366" },
							className: "group/social grid size-9 place-items-center rounded-full shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/60",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialIcon, {
								path: WHATSAPP_PATH,
								className: "size-[18px] text-white transition-transform duration-200 group-hover/social:scale-110"
							})
						}) : null]
					})
				] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-navy-foreground/10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-navy-foreground/60 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" ZUCUR MART. All rights reserved."
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Prices are indicative wholesale rates and exclusive of taxes unless stated." })]
			})
		})]
	});
}
var NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/categories",
		label: "Categories"
	},
	{
		to: "/products",
		label: "Products"
	},
	{
		to: "/bulk-order-inquiry",
		label: "Bulk Order Inquiry"
	},
	{
		to: "/about",
		label: "About"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [term, setTerm] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const { data: settings } = useQuery(settingsQuery);
	function submitSearch(event) {
		event.preventDefault();
		setOpen(false);
		navigate({
			to: "/products",
			search: term.trim() ? { q: term.trim() } : {}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden bg-navy text-navy-foreground md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-1.5 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-navy-foreground/80",
						children: "Wholesale only · Minimum order quantities apply · GST invoicing"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4",
						children: [settings?.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${settings.phone}`,
							className: "flex items-center gap-1.5 hover:text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-3" }), settings.phone]
						}) : null, settings?.business_hours ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-navy-foreground/70",
							children: settings.business_hours
						}) : null]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl items-center gap-3 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex shrink-0 items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/favicon.ico",
							alt: "ZUCUR MART logo",
							className: "h-12 w-auto object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "leading-none",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-lg font-extrabold tracking-tight text-navy",
								children: "ZUCUR MART"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground",
								children: "B2B Wholesale"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "ml-4 hidden items-center gap-1 lg:flex",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							activeOptions: { exact: item.to === "/" },
							activeProps: { className: "bg-secondary text-primary" },
							className: "rounded-md px-3 py-2 text-sm font-medium text-foreground/80 transition-colors hover:bg-secondary hover:text-primary",
							children: item.label
						}, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						onSubmit: submitSearch,
						className: "ml-auto hidden w-56 xl:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: term,
								onChange: (e) => setTerm(e.target.value),
								placeholder: "Search products or SKU",
								className: "h-9 pl-8",
								"aria-label": "Search products"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "ml-auto lg:hidden",
						onClick: () => setOpen((v) => !v),
						"aria-label": "Toggle menu",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border bg-card px-4 pb-4 lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						onSubmit: submitSearch,
						className: "pt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-2.5 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: term,
								onChange: (e) => setTerm(e.target.value),
								placeholder: "Search products or SKU",
								className: "h-9 pl-8",
								"aria-label": "Search products"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-3 grid gap-1",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							onClick: () => setOpen(false),
							className: "rounded-md px-3 py-2 text-sm font-medium text-foreground/80 hover:bg-secondary hover:text-primary",
							children: item.label
						}, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "mt-1 w-full",
						onClick: () => setOpen(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), " Close"]
					})
				]
			}) : null
		]
	});
}
function VisitorGate() {
	const { visitor, ready, register } = useVisitor();
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)({});
	const open = ready && !visitor;
	async function handleSubmit(event) {
		event.preventDefault();
		const next = {};
		if (name.trim().length < 2) next.name = "Please enter your full name";
		if (phone.trim().replace(/\D/g, "").length < 8) next.phone = "Enter a valid phone number";
		if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) next.email = "Enter a valid email address";
		setErrors(next);
		if (Object.keys(next).length > 0) return;
		setSaving(true);
		try {
			await register({
				name,
				phone,
				email
			});
			toast.success("Welcome to ZUCUR MART wholesale catalogue");
		} catch {
			toast.error("Could not save your details. Please try again.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md overflow-hidden border-0 p-0 [&>button]:hidden sm:max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-navy px-6 py-6 text-navy-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs font-semibold uppercase tracking-[0.25em] text-gold",
						children: "Wholesale Access"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "mt-2 font-display text-2xl font-bold",
						children: "ZUCUR MART"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-1 text-sm text-navy-foreground/75",
						children: "Share your business contact to browse wholesale pricing, MOQ and availability."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "space-y-4 px-6 pb-6 pt-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "gate-name",
								children: "Full Name *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "gate-name",
								value: name,
								maxLength: 100,
								onChange: (e) => setName(e.target.value),
								placeholder: "e.g. Rahul Mehta"
							}),
							errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.name
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "gate-phone",
								children: "Phone Number *"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "gate-phone",
								value: phone,
								maxLength: 20,
								inputMode: "tel",
								onChange: (e) => setPhone(e.target.value),
								placeholder: "e.g. +91 98765 43210"
							}),
							errors.phone ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.phone
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "gate-email",
								children: "Email (optional)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "gate-email",
								value: email,
								maxLength: 150,
								onChange: (e) => setEmail(e.target.value),
								placeholder: "purchase@company.com"
							}),
							errors.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-destructive",
								children: errors.email
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: saving,
						children: saving ? "Please wait…" : "Enter Catalogue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-start gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mt-0.5 size-3.5 shrink-0 text-primary" }), "Your details are used only for wholesale enquiries and quotations."]
					})
				]
			})]
		})
	});
}
function SiteLayout({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VisitorGate, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FloatingSocialBar, {})
		]
	});
}
function PageHeader({ title, subtitle, eyebrow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-navy text-navy-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-10 sm:py-14",
			children: [
				eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs font-semibold uppercase tracking-[0.25em] text-gold",
					children: eyebrow
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-3xl font-extrabold sm:text-4xl",
					children: title
				}),
				subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-sm leading-relaxed text-navy-foreground/75 sm:text-base",
					children: subtitle
				}) : null
			]
		})
	});
}
//#endregion
export { formatPrice as a, productQuery as c, categoriesQuery as i, productsQuery as l, SiteLayout as n, hasDiscount as o, bannersQuery as r, productImage as s, PageHeader as t, settingsQuery as u };
