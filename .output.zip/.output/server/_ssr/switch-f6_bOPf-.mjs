import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, t as Button } from "./button-DRsC1qZi.mjs";
import { n as Label } from "./input-CoDpKGui.mjs";
import { D as ImagePlus, s as Star, t as X, w as LoaderCircle } from "../_libs/lucide-react.mjs";
import { c as uploadImages, s as imageSrc } from "./dialog-CGvJfmGP.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/switch-f6_bOPf-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ImageUploader({ value, onChange, folder, multiple = false, label = "Image", hint }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function handleFiles(files) {
		if (!files || files.length === 0) return;
		setBusy(true);
		try {
			const uploaded = await uploadImages(Array.from(files), folder);
			onChange(multiple ? [...value, ...uploaded] : uploaded.slice(-1));
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Image upload failed. Please try again.");
		} finally {
			setBusy(false);
			if (inputRef.current) inputRef.current.value = "";
		}
	}
	function removeAt(index) {
		onChange(value.filter((_, i) => i !== index));
	}
	function makeMain(index) {
		const next = [...value];
		const [picked] = next.splice(index, 1);
		if (picked) next.unshift(picked);
		onChange(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }),
			value.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-3",
				children: value.map((url, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative size-24 overflow-hidden rounded-md border border-border bg-secondary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: imageSrc(url) ?? "",
							alt: "",
							className: "size-full object-cover"
						}),
						multiple && index === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute inset-x-0 bottom-0 bg-navy/80 py-0.5 text-center text-[10px] font-semibold text-navy-foreground",
							children: "Main"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute right-1 top-1 flex gap-1",
							children: [multiple && index > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => makeMain(index),
								title: "Set as main image",
								className: "grid size-6 place-items-center rounded bg-navy/80 text-navy-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3" })
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => removeAt(index),
								title: "Remove image",
								className: "grid size-6 place-items-center rounded bg-destructive text-destructive-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" })
							})]
						})
					]
				}, url + index))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*",
				multiple,
				className: "hidden",
				onChange: (e) => void handleFiles(e.target.files)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				disabled: busy,
				onClick: () => inputRef.current?.click(),
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }), busy ? "Uploading…" : value.length ? multiple ? "Upload more images" : "Upload new image" : multiple ? "Upload images" : "Upload image"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: hint ?? "JPG, PNG, WEBP, AVIF or GIF · up to 10 MB per image."
			})
		]
	});
}
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") })
}));
Switch.displayName = Switch$1.displayName;
//#endregion
export { Switch as n, ImageUploader as t };
