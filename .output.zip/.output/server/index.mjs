globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about--VopnXni.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1101-qMW+Dwu1rSgWEze3H1rr79GvLvY\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 4353,
		"path": "../public/assets/about--VopnXni.js"
	},
	"/assets/admin-D3WJpKN2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1417-kq+juEPXlVQzkV2ZIt7mi9zzlzo\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 5143,
		"path": "../public/assets/admin-D3WJpKN2.js"
	},
	"/assets/admin.banners-DtBsjRDX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2276-iHQ7MMNpSZYqKhFf4PII0zmQDuw\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 8822,
		"path": "../public/assets/admin.banners-DtBsjRDX.js"
	},
	"/assets/admin.index-II0um38v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e4f-cHHpO+6xubKt8UeqyaHpbLdhvtQ\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 3663,
		"path": "../public/assets/admin.index-II0um38v.js"
	},
	"/assets/admin.inquiries-Dz6_OlNY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ecd-ccB747eMYImDyf1KBfP8rdniupE\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 3789,
		"path": "../public/assets/admin.inquiries-Dz6_OlNY.js"
	},
	"/assets/admin.categories-D6CTDAyw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a58-r9BqdiObXyOlNh74g2d3dZE0Gto\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 6744,
		"path": "../public/assets/admin.categories-D6CTDAyw.js"
	},
	"/assets/admin.products-BzV_EgOm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f23-f4uZkUB03hBwv40FACwnhMU2L3s\"",
		"mtime": "2026-09-21T04:42:29.578Z",
		"size": 12067,
		"path": "../public/assets/admin.products-BzV_EgOm.js"
	},
	"/assets/admin.settings-BgT4fofH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f77-KLAtcp9ng6xO2PcXb5BVHizfpKY\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 3959,
		"path": "../public/assets/admin.settings-BgT4fofH.js"
	},
	"/assets/admin.visitors-7WajisCl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1a-OUNI4OJ11HuQAcKQ1WT5CX+0h9Y\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 2842,
		"path": "../public/assets/admin.visitors-7WajisCl.js"
	},
	"/assets/admin.whatsapp-D07weqit.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fed-lcx80+RC98XgctXC3H5g8YV9plE\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 4077,
		"path": "../public/assets/admin.whatsapp-D07weqit.js"
	},
	"/assets/arrow-right-CczGO6rn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-tgLIKPtJlNrnnrPQsxHkAT5d4jg\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 165,
		"path": "../public/assets/arrow-right-CczGO6rn.js"
	},
	"/assets/badges-CgaXKITV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"67d-VkSurEXBgMbCNTYe637R2SKSl7A\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 1661,
		"path": "../public/assets/badges-CgaXKITV.js"
	},
	"/assets/auth-9Ki3-ktT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d50-I0llTAnvfiEPRoms7zmXK1pegBo\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 3408,
		"path": "../public/assets/auth-9Ki3-ktT.js"
	},
	"/assets/categories.index-B4jFoW1y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"689-zWazWhG3i1AXZTnJaMnQhWDKr7A\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 1673,
		"path": "../public/assets/categories.index-B4jFoW1y.js"
	},
	"/assets/bulk-order-inquiry-T9nlj-cc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2459-TaMvxrLssQMG1umbMuefpE9/Zwg\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 9305,
		"path": "../public/assets/bulk-order-inquiry-T9nlj-cc.js"
	},
	"/assets/categories._slug-ztXlM79L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"565-ZuKVBjoMQ4MPib252InXVPiCDkc\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 1381,
		"path": "../public/assets/categories._slug-ztXlM79L.js"
	},
	"/assets/button-DbXrzmbF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7e4b-I5813QNbBLu/Wmuzpxqs0vNjxr8\"",
		"mtime": "2026-09-21T04:42:29.580Z",
		"size": 32331,
		"path": "../public/assets/button-DbXrzmbF.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-19T06:52:03.714Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/clipboard-list-sVTcPZ0V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19b-gZxxKuoyqmUXsYI4LBYEPClYG7E\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 411,
		"path": "../public/assets/clipboard-list-sVTcPZ0V.js"
	},
	"/assets/contact-Bk_cO7em.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d0a-5kwjNdj7fzaKJTJp80JBEeP64+0\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 7434,
		"path": "../public/assets/contact-Bk_cO7em.js"
	},
	"/assets/createLucideIcon-C_LCJTxh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-O9+czQKFHMACYTYdFrR18PV0PjE\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-C_LCJTxh.js"
	},
	"/assets/dist-ztA8otqi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"281-YimwjDL/5vBY/tkKV+NwqjHf+kk\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 641,
		"path": "../public/assets/dist-ztA8otqi.js"
	},
	"/assets/dialog-DlkNff0R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8eaf-pqQI5JyxJGc1w1tJvFAuMxxoQeY\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 36527,
		"path": "../public/assets/dialog-DlkNff0R.js"
	},
	"/zucurmart-footer-logo.png": {
		"type": "image/png",
		"etag": "\"35d3c-a8AWY2E8NkZfVuipkLkw5bzgc18\"",
		"mtime": "2026-09-19T09:36:08.638Z",
		"size": 220476,
		"path": "../public/zucurmart-footer-logo.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"6987e-0wHG8lD9nak8tmV1gENgVws61RQ\"",
		"mtime": "2026-09-19T09:38:46.250Z",
		"size": 432254,
		"path": "../public/favicon.ico"
	},
	"/assets/image-off-BRfpPIGJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d7-X7O5qoT7k5ei6bmgA5dE3lpQjJQ\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 471,
		"path": "../public/assets/image-off-BRfpPIGJ.js"
	},
	"/assets/input-Y2S197YS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6c0-NZJGtbRZhuKIafr4N3vb1QnhOYA\"",
		"mtime": "2026-09-21T04:42:29.582Z",
		"size": 1728,
		"path": "../public/assets/input-Y2S197YS.js"
	},
	"/assets/jsx-runtime-Dk72oS4N.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2246-jdmifwUklrWzVvkkm/k29uuTwFE\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 8774,
		"path": "../public/assets/jsx-runtime-Dk72oS4N.js"
	},
	"/assets/link-B1sIwsDb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1120-p0gB4hhSdlnMXeoX0Q1sIMpVQyw\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 4384,
		"path": "../public/assets/link-B1sIwsDb.js"
	},
	"/assets/loader-circle-CT4tTHMc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90-Yf+XjUKAnu/4opPSZ58r8SmVE+I\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 144,
		"path": "../public/assets/loader-circle-CT4tTHMc.js"
	},
	"/assets/Match-BdtnWgoZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bddd-vAteZInWOSqAAIrC5OevCzDmRUA\"",
		"mtime": "2026-09-21T04:42:29.576Z",
		"size": 48605,
		"path": "../public/assets/Match-BdtnWgoZ.js"
	},
	"/assets/matchContext-Cp3bjMzx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29c-atVaZvXhvgQ1PeTT80n75eA5rCc\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 668,
		"path": "../public/assets/matchContext-Cp3bjMzx.js"
	},
	"/assets/message-circle-B6snYVnP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f1-eWMFsKIbHNQnHmF6bv4Y/UCWutA\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 241,
		"path": "../public/assets/message-circle-B6snYVnP.js"
	},
	"/assets/package-2PXSjMVl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174-KoUg/kQFp07DfbfCu+7kGH7AI4M\"",
		"mtime": "2026-09-21T04:42:29.610Z",
		"size": 372,
		"path": "../public/assets/package-2PXSjMVl.js"
	},
	"/assets/Pagination-DWsVCHTt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48b-Tj6Ff1hXYoh8WaBxIkCIXfMyB3w\"",
		"mtime": "2026-09-21T04:42:29.577Z",
		"size": 1163,
		"path": "../public/assets/Pagination-DWsVCHTt.js"
	},
	"/assets/ProductCard-D8zGFfj9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1a-ZpSZ1twaPF7AKQn5LPSCxCd2Q+c\"",
		"mtime": "2026-09-21T04:42:29.577Z",
		"size": 2842,
		"path": "../public/assets/ProductCard-D8zGFfj9.js"
	},
	"/assets/privacy-policy-DRYH70Au.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a7-bwXis8MJazPLOW0O62kcliV7rc0\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 2215,
		"path": "../public/assets/privacy-policy-DRYH70Au.js"
	},
	"/assets/products.index-wVEQZLHX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e5-oGPwCsrZy0KqB9tWgnNJa4BC7aM\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 4325,
		"path": "../public/assets/products.index-wVEQZLHX.js"
	},
	"/assets/products._slug-C0iN5J2o.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1579-//fTFngzjYDTNptSV0URjppxMmo\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 5497,
		"path": "../public/assets/products._slug-C0iN5J2o.js"
	},
	"/assets/react-dom-CxAQt2Ay.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f17-pkyc8i9fR8ycdAMyclNWgBjMoyQ\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 3863,
		"path": "../public/assets/react-dom-CxAQt2Ay.js"
	},
	"/assets/route-DcHSqdYJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-zvFjzYD0TM79dGU6UREl0IlDrvs\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 141,
		"path": "../public/assets/route-DcHSqdYJ.js"
	},
	"/assets/routes-Bt21cwIa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d13-FxIy1ghpt6QOyWHL4651KTkwBPQ\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 15635,
		"path": "../public/assets/routes-Bt21cwIa.js"
	},
	"/assets/search-BfnvExII.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-J+m1+o1gTqjs1kxwUFOBRANg4Vs\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 174,
		"path": "../public/assets/search-BfnvExII.js"
	},
	"/assets/select-DvP8C0Mz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d777-vCKsieiSjuLTk3favuzO6rQEiIo\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 55159,
		"path": "../public/assets/select-DvP8C0Mz.js"
	},
	"/assets/SiteLayout-FLZgcMIU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"569c-hr46dGxbOPukan7tTjiVcp5/Gr4\"",
		"mtime": "2026-09-21T04:42:29.577Z",
		"size": 22172,
		"path": "../public/assets/SiteLayout-FLZgcMIU.js"
	},
	"/assets/terms-zH6e9LON.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"849-XQNfvUstiHB/4SNjJSlyA3KZ7r8\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 2121,
		"path": "../public/assets/terms-zH6e9LON.js"
	},
	"/assets/switch-DHu0V6MP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ebe-l60KwnrhYQHP59p1urp4oZ1VApo\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 7870,
		"path": "../public/assets/switch-DHu0V6MP.js"
	},
	"/assets/textarea-DFm_dXg-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"208-eXeaJAF0pxRjwe2Qj+vm8B5mxcI\"",
		"mtime": "2026-09-21T04:42:29.611Z",
		"size": 520,
		"path": "../public/assets/textarea-DFm_dXg-.js"
	},
	"/assets/styles-DKcUZ5Cw.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16d86-1dQZndy/wx43m8eXFWUwLeZaPs4\"",
		"mtime": "2026-09-21T04:42:29.615Z",
		"size": 93574,
		"path": "../public/assets/styles-DKcUZ5Cw.css"
	},
	"/assets/index-4UYZG4Sd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"89186-WAOr8kUmLW4IrTqPQmSDa9pvYss\"",
		"mtime": "2026-09-21T04:42:29.576Z",
		"size": 561542,
		"path": "../public/assets/index-4UYZG4Sd.js"
	},
	"/assets/truck-D05o4RBk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"196-b4dhhxuGvwqeJIrn0maydt3v0Lg\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 406,
		"path": "../public/assets/truck-D05o4RBk.js"
	},
	"/assets/useMutation-dP6s1jTo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"922-LKitXKMw4L0VUz16+aITHmHAYwE\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 2338,
		"path": "../public/assets/useMutation-dP6s1jTo.js"
	},
	"/assets/useQuery-Cy8wIJcD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f19-p6dVivUMbENiy9Or3u/MQr0/APE\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 7961,
		"path": "../public/assets/useQuery-Cy8wIJcD.js"
	},
	"/assets/users-BwZkkB-R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-/qxTNuzoVz7CzX59XMdhKdTAMeE\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 306,
		"path": "../public/assets/users-BwZkkB-R.js"
	},
	"/assets/useStore-DG2WmC1C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4af0-0kloGZhgbWRZlqNVawaQ+t42WrQ\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 19184,
		"path": "../public/assets/useStore-DG2WmC1C.js"
	},
	"/assets/zucur_logo-DdEwhPLs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-Tk9p42kIQj++Ib72bfagXKaDJ7g\"",
		"mtime": "2026-09-21T04:42:29.613Z",
		"size": 55,
		"path": "../public/assets/zucur_logo-DdEwhPLs.js"
	},
	"/assets/WhatsappEnquiryButton-D4kUqL_h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ab8-M/m5fKckZKeTmQdufifC4zjZGfM\"",
		"mtime": "2026-09-21T04:42:29.577Z",
		"size": 2744,
		"path": "../public/assets/WhatsappEnquiryButton-D4kUqL_h.js"
	},
	"/assets/zucur_logo-DO8iOKc8.png": {
		"type": "image/png",
		"etag": "\"24ab0-2h6ssjMDnaybQwY2iBbVOHo/UVk\"",
		"mtime": "2026-09-21T04:42:29.615Z",
		"size": 150192,
		"path": "../public/assets/zucur_logo-DO8iOKc8.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_y8b3wR = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_y8b3wR
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
